//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef PROJECTILE_HPP
#define PROJECTILE_HPP

#include "constantes.hpp"

#include "ObjetMonde.hpp"

class Pion;
class Monde;
class Ephemere;
class ObjectData;

/*!
    \enum KindOfDeath
    \brief Comment est mort le projectile
*/
enum KindOfDeath {
    OUT_OF_MAP,     //!< Sortie de la carte
    KILLED_SOMEONE, //!< A tué quelqu'un
    REACH_OBSTACLE  //!< A touché un obstacle solide
};


/*!
    \class Projectile
    \brief Un missile, une balle... Laissez libre cours à votre imagination
*/

class Projectile : public ObjetMonde {

public :

        /*!
            \param monde Le monde dans lequel évolue le projectile
            \param tireur Le pion qui a tiré ce missile (il ne peut être touché par celui ci)
            \param cible La position visée par le missile
            \param vitesseMissile La vitesse de déplacement du missile
            \param tailleMissile La taille de la représentation graphique du missile
            \param anim La superbe animation à afficher à l'écran
            \param objectData Les données attachées à cet objet
        */
        Projectile(
                Monde *monde,
                const Pion *tireur,
                const sf::Vector2f &cible,
                const float vitesseMissile,
                const sf::Vector2f &tailleMissile,
                ImgAnim *anim,
                ObjectData *objectData
        );

        /*!
            \brief Mise à jour de la position du missile
        */
        void update();

        /*!
            \brief Cette méthode va servir à l'IA afin de savoir si elle peut toucher le joueur.
            Elle va simuler le trajet trajet du missile via cette méthode
            \param joueur La cible du tir (celui que l'on veut essayer de toucher)
            \return Vrai si la cible est touchée, faux sinon
        */
        bool simulerTir(const Pion *joueur);

        /*!
            \brief Ce missile va t il toucher le pion cible dans un avenir proche ?
        */
        bool vaBientotToucher(const Pion *cible);

        /*!
            \brief Obtient un pointeur sur le tireur de ce missile
        */
        const Pion * getTireur() const;

        /*!
            \brief Obtient le vecteur de déplacement du missile
        */
        const sf::Vector2f & getDeplacement() const;

        /*!
            \brief Dit à l'objet de balancer son animation de fin, et son son de destruction par exemple
        */
        virtual void actionAvantDestruction();

private :
        /*!
            \brief Test si un objet placé en position et de taille taille est touché par le missile
            \param p Le pion que l'on veut savoir si l'on à touché
        */
        bool touchePion(const Pion *p) const;


protected :

        sf::Vector2f m_vecteurDeplacement;  //!< Le vecteur de déplacement du missile

        const Pion *m_tireur;               //!< Le tireur du missile

        bool m_simulation;                  //! Sommes nous en mode simulation ? L'IA fait des simulations pour savoir où ira le missile

        float m_vitesseMissile;             //!< Vitesse des projectiles

        KindOfDeath m_death;                //!< Comment suis-je mort ?

};

#endif // PROJECTILE_HPP

