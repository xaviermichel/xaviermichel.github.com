//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef FACTORY_OBJECT_HPP
#define FACTORY_OBJECT_HPP

#include "constantes.hpp"

#include "Singleton.hpp"

#include "ObjetMonde.hpp"

class Monde;
class Pion;


/*!
    \struct WeaponsData
    \brief Les données qui concernent les armes (en plus de ObjectData)
*/
struct WeaponsData {
    float speed;            //!< Vitesse du projectile
    float reload;           //!< Temps de rechargement
    char* uiImage;          //!< Nom de l'image à afficher dans l'interface utilisateur
    char* mouseImage;       //!< Image du viseur
};


/*!
    \struct EphemeralData
    \brief Les données qui concernent les éphémères (en plus de ObjectData)
*/
struct EphemeralData {
};


/*!
    \struct ObjectData
    \brief Toutes les données que l'on pretera à l'objet à sa création
    Ces données sont chargées depuis un xml au lancement de l'application
    Les déclencheurs sont onCreate, onDestroy par exemple.
*/
struct ObjectData {
    TYPE_OBJET type;                                                            //!< Mon type d'objet
    float width;                                                                //!< Largeur de l'objet
    float height;                                                               //!< Hauteur de l'objet
    std::multimap<std::string, std::string> sounds;                             //!< Mes sons (déclencheurs / nom du son)
    std::multimap<std::string, std::string> images;                             //!< Mes images (déclencheur / nom de l'image)
    std::multimap<std::string, std::string> ephemerals;                         //!< Mes éphémères (déclencheur / nom de l'éphémère)
    std::multimap<std::pair<std::string, std::string>, std::string> conditions; //!< Les conditions pour faire une action (<déclencheur, action>, condition>
    union {
        WeaponsData weaponData;                                                 //!< On a soit des données qui nous concernent en temps qu'arme
        EphemeralData ephemeralData;                                            //!< Soit des données qui nous concerne en temps qu'éphémère
    };
};




/*!
    \class ObjectFactory
    \brief La fabrique d'objet, qui contient toutes les données en mémoire car elle a chargé le xml au démarage
*/

class ObjectFactory : public Singleton<ObjectFactory>
{

friend class Singleton<ObjectFactory>;

public :

    /*!
        \brief Créer l'éphémère demandé dans le monde donné et l'ajoute dans le monde
        \param name Nom de l'objet demandé
        \param m Le monde dans lequel évolura l'objet
        \param position La position de l'éphémère
    */
    static ObjetMonde* createEphemere(
            const std::string &name,
            Monde *m,
            const sf::Vector2f &position
    );

    /*!
        \brief Créer le projectile demandé dans le monde donné et l'ajoute dans le monde
        \param name Nom de l'objet demandé
        \param m Le monde dans lequel évolura l'objet
        \param tireur Le pion qui vient de tirer le projectile
        \param cible Le point visé
    */
    static ObjetMonde* createProjectile(
            const std::string &name,
            Monde *m,
            const Pion *tireur,
            const sf::Vector2f &cible
     );

    static const WeaponsData& getWeaponData(const std::string &arme);


protected :

    ObjectFactory();

    ~ObjectFactory();

    std::map<std::string, ObjectData *> m_ressources;     //!< Toutes les données concernant les objets du monde (nom ressource => valeurs de création )

};

#endif

