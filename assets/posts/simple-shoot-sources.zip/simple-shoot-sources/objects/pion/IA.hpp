//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef IA_HPP
#define IA_HPP

#include "constantes.hpp"

#include "Pion.hpp"

/*!
    \class IA
    \brief Les bots qui évoluent sur la carte, avec une pseudo intelligence
*/

class IA : public Pion {

public:

        /*!
          \param monde Le monde dans lequel évolue l'IA
          \param position La position initiale de l'IA
          \param cadenseTirIA Temps entre deux tirs de l'IA, en secondes
          \param arme L'arme que possède l'IA
          \param peutBougerEnTirant Ce bot peuvent il bouger et tirer en même temps ?
          \param nombreTourSimulation Nombre de tours de simulation pour voir si le pion va se faire toucher par le missile (l'IA se sert de cela pour savoir si elle va se faire toucher prochainement)
          \param tempsEntreDeuxEsquives Temps entre deux tentatives d'esquives de l'IA
          \param deltaDeplacementEsquive Nombre de largeurMissile que l'on va chercher à contourner pendant l'esquive
          \param taillePion Taille du pion
        */
        IA(
                Monde *monde,
                const sf::Vector2f &position,
                const float cadenseTirIA,
                const std::string &arme,
                const bool peutBougerEnTirant = true,
                const uchar nombreTourSimulation = 18,
                const float tempsEntreDeuxEsquives = 0.5,
                const uchar deltaDeplacementEsquive = 4,
                const sf::Vector2f &taillePion = sf::Vector2f(16, 24)
         );


        /*!
            \brief Mise à jour du bot, via une intelligence artificielle
        */
        void update();

        /*!
            \brief Déplacement et mise à jour de l'animation (tourner l'image dans la bonne direction)
        */
        void deplacer();

        /*!
            \brief Renvoie le nombre de tours de simulation pour voir les missiles arriver
        */
        uchar getNombreTourSimulation() const;


protected :

        /*!
            \brief Le bot peut-il toucher le joueur ?
        */
        bool peutToucherLeJoueur() const;


        /*!
            \brief Le bot va t il se faire toucher par un missile ? Si oui cette fonction l'esquive
            \return Vrai si il y avait bien un missile a esquiver
        */
        bool esquiverMissiles();




        bool m_esquiveEnCours;                    //!< L'IA est-elle en train d'esquiver un missile ? Auquel cas elle renonce à faire son déplacement vers le joueur

        sf::Clock m_clockLimitationCadenceTir;    //!< Cette horloge sert à limiter la cadence de tir, sinon le bot aurait un effet "mitraillette" face au joueur

        sf::Clock m_clockEsquiveMissile;          //!< Cette horloge limite le nombre de recherche de chemin pour esquiver un missile, pour ne pas que l'IA soit impossible à battre et pour ne pas faire ralentir le jeu

        std::list<Point> m_chemin;                //!< Liste des points qui vont composer le chemin à suivre par le bot, défini lors de l'appel au A* \sa Pathfinding

        float m_tempsEntreDeuxEsquives;           //!< Temps entre deux tentatives d'esquives de l'IA

        uchar m_deltaDeplacementEsquive;          //!< Nombre de largeurMissile que l'on va chercher à contourner pendant l'esquive

        float m_cadenseTirIA;                     //!< Temps entre deux tirs de l'IA, en secondes

        bool m_peutBougerEnTirant;                //!< Les bots peuvent ils bouger et tirer en même temps ?

        uchar m_nombreTourSimulation;             //!< Nombre de tours de simulation pour voir si le pion va se faire toucher par le missile (l'IA se sert de cela pour savoir si elle va se faire toucher prochainement)

};

#endif // IA_HPP
