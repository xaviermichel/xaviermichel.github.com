//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "IA.hpp"

#include "ObjectFactory.hpp"

#include "Monde.hpp"

#include "Pathfinding.hpp"
#include "ImageManager.hpp"

using namespace sf;

IA::IA(Monde *monde, const sf::Vector2f &position, const float cadenseTirIA, const std::string &arme, const bool peutBougerEnTirant, const uchar nombreTourSimulation,
       const float tempsEntreDeuxEsquives, const uchar deltaDeplacementEsquive, const sf::Vector2f &taillePion)
    : Pion(monde, position, taillePion, arme, /*vitesse = */2.f), m_tempsEntreDeuxEsquives(tempsEntreDeuxEsquives),
        m_deltaDeplacementEsquive(deltaDeplacementEsquive), m_cadenseTirIA(cadenseTirIA),
        m_peutBougerEnTirant(peutBougerEnTirant), m_nombreTourSimulation(nombreTourSimulation), m_esquiveEnCours(false)
{
    m_clockLimitationCadenceTir.Reset();
    m_clockEsquiveMissile.Reset();
}

void IA::update() {

    if ( ! m_monde->getPionJoueur()->aDetruire() ) {

        Vector2f cible = m_monde->getPionJoueur()->getPosition();

        if ( ! esquiverMissiles() ) {

            if ( m_clockLimitationCadenceTir.GetElapsedTime() > m_cadenseTirIA ) {
                if ( peutToucherLeJoueur() ) {
                        tirer(cible);
                        m_chemin.clear();
                        m_clockLimitationCadenceTir.Reset();
                }
            }

            if ( m_peutBougerEnTirant ) { // bouger ou tirer, il faut choisir
                if ( m_chemin.empty() && ! m_esquiveEnCours ) {
                    PathFinding pf(&distanceManhattan, m_position, cible, m_monde, this);
                    m_chemin = pf.lancer();
                }
                deplacer();
            }
        }

    }
}


bool IA::peutToucherLeJoueur() const {
    Vector2f cible = m_monde->getPionJoueur()->getPosition();
    Projectile *p = static_cast<Projectile *>(ObjectFactory::createProjectile(m_armeManager.currentWeapon(), m_monde, this, cible));
    bool ret = p->simulerTir(m_monde->getPionJoueur());
    delete p;
    return ret;
}


void IA::deplacer() {

    if ( ! m_chemin.empty() ) {
        Point p = m_chemin.front();

        m_chemin.pop_front();


        // tourner l'IA dans le bon sens
        sf::Vector2f vecteurDeplacement = Vector2f( (p.first - m_position.x), (p.second - m_position.y));

        if ( std::abs(vecteurDeplacement.x) > std::abs(vecteurDeplacement.y) ) { // on préfère afficher le déplacement sur x
            setAnimationRow( vecteurDeplacement.x > 0 ? DROITE : GAUCHE );
        } else { // plutôt le déplacement sur y
            setAnimationRow( vecteurDeplacement.y > 0 ? BAS : HAUT );
        }

        // changer de position
        m_position = Vector2f(p.first, p.second);

    }

}


bool IA::esquiverMissiles() {

    bool vaSeFaireToucher = false;
    Projectile *p;

    for (std::vector<ObjetMonde *>::const_iterator it = m_monde->getVObjetMonde().begin(); it != m_monde->getVObjetMonde().end() && ! vaSeFaireToucher; ++it) {
        if ( (*it)->getType() == TYPE_PROJECTILE ) { // on ne s'interesse qu'aux colision avec les projectiles
            p = static_cast<Projectile *>(*it);
            vaSeFaireToucher = p->vaBientotToucher(this);
        }
    }

    if ( m_clockEsquiveMissile.GetElapsedTime() > m_tempsEntreDeuxEsquives ) {
        m_esquiveEnCours = false;
    }


    if ( vaSeFaireToucher ) { // je vais me faire toucher, par *it (p)

        m_esquiveEnCours = true;

        if ( m_clockEsquiveMissile.GetElapsedTime() < m_tempsEntreDeuxEsquives ) {
            return false;
        }
        m_clockEsquiveMissile.Reset();

        Vector2f deplacementMissile = p->getDeplacement();
        Vector2f positionFuture;
        bool positionFutureDefinie = false;

        if ( std::abs(deplacementMissile.x) > std::abs(deplacementMissile.y) ) {
            // le déplacement sur x est plus important, on va donc le prendre en priorité
            // on va tenter d'aller en haut ou en bas

            positionFuture.x = m_position.x;

            if ( deplacementMissile.y > 0 ) { // on va tenter d'aller en haut

                if ( ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y - p->getTaille().y*m_deltaDeplacementEsquive) == couleurLibre ) {
                    positionFuture.y = m_position.y - p->getTaille().y*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                }
                else if ( ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y + p->getTaille().y*m_deltaDeplacementEsquive) == couleurLibre ) {
                   positionFuture.y = m_position.y + p->getTaille().y*m_deltaDeplacementEsquive;
                   positionFutureDefinie = true;
                }

            } else { // et ben le bas alors

                if ( ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y + p->getTaille().y*m_deltaDeplacementEsquive) == couleurLibre ) {
                   positionFuture.y = m_position.y + p->getTaille().y*m_deltaDeplacementEsquive;
                   positionFutureDefinie = true;
                } else if ( ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y - p->getTaille().y*m_deltaDeplacementEsquive) == couleurLibre ) {
                    positionFuture.y = m_position.y - p->getTaille().y*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                }

            }

        } else {
            // le déplacement sur y est plus important, on va donc le prendre en priorité
            // on va tenter d'aller à gauche ou à droite

            positionFuture.y = m_position.y;

            if ( deplacementMissile.x < 0 ) { // on va tenter la droite

                if ( ImageManager::getImage("collision")->GetPixel(m_position.x + p->getTaille().x*m_deltaDeplacementEsquive, m_position.y) == couleurLibre ) {
                    positionFuture.x = m_position.x + p->getTaille().x*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                } else if ( ImageManager::getImage("collision")->GetPixel(m_position.x - p->getTaille().x*m_deltaDeplacementEsquive, m_position.y) == couleurLibre ) {
                    positionFuture.x = m_position.x - p->getTaille().x*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                }

            } else { // donc ce sera la gauche

                if ( ImageManager::getImage("collision")->GetPixel(m_position.x - p->getTaille().x*m_deltaDeplacementEsquive, m_position.y) == couleurLibre ) {
                    positionFuture.x = m_position.x - p->getTaille().x*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                } else if ( ImageManager::getImage("collision")->GetPixel(m_position.x + p->getTaille().x*m_deltaDeplacementEsquive, m_position.y) == couleurLibre ) {
                    positionFuture.x = m_position.x + p->getTaille().x*m_deltaDeplacementEsquive;
                    positionFutureDefinie = true;
                }
            }

        }

        if ( positionFutureDefinie ) {
            m_chemin.clear();
            PathFinding pf(&distanceManhattan, m_position, positionFuture, m_monde, this);
            m_chemin = pf.lancer();
        } else {
            m_esquiveEnCours = false;
        }

        deplacer();
    }

    return vaSeFaireToucher;
}


uchar IA::getNombreTourSimulation() const {
    return m_nombreTourSimulation;
}

