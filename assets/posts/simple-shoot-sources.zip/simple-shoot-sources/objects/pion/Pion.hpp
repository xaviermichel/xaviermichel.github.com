//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef PION_HPP
#define PION_HPP

#include "constantes.hpp"

#include "ObjetMonde.hpp"
#include "ArmeManager.hpp"

class Monde;
class Projectile;

/*!
    \class Pion
    \brief Un pion est un un Joueur ou une IA
*/


class Pion : public ObjetMonde {

public :

        /*!
            \param monde Le monde dans lequel évolue le pion
            \param position La position initiale du pion
            \param taillePion La taille du pion
            \param arme L'arme que le pion va utiliser
        */
        Pion(
                Monde *monde,
                const sf::Vector2f &position,
                const sf::Vector2f &taillePion,
                const std::string &arme,
                const float vitesse
        );

        /*!
            \brief Tirer un projectile
            \param cible Le point visé par le missile
            Le projectile partira de la position du pion et se dirigera vers cible
            Le tir est proposé à ArmeManager qui ne l'acceptera que si le temps de recharche est écoulé
        */
        void tirer(const sf::Vector2f &cible);

        /*!
            \brief Le pion va tenter de se déplacer dans la direction donnée si cela est possible
            (en réalité, cette méthode n'est appelée que pour le joueur)
        */
        void deplacer(const DIRECTION d);

        /*!
            \brief Ajoute une arme au pion
        */
        virtual void addWeapon(const std::string &arme);

        /*!
            \brief Enleve une arme au pion
        */
        virtual void removeWeapon(const std::string &arme);

        /*!
            \brief Ordonne au pion de selectionner l'arme suivante
        */
        virtual void nextWeapon();

        /*!
            \brief Ordonne au pion de selectionner l'arme précédente
        */
        virtual void previousWeapon();

        /*!
            \brief Renvoie l'arme courrante
        */
        const std::string & currentWeapon() const;

        /*!
            \brief Renvoie la vitesse du pion
        */
        float getVitesse() const;

protected :

        ArmeManager m_armeManager;        //!< Les armes que je possède

        float m_vitesse;                  //!< Ma vitesse

};


#endif // PION_HPP

