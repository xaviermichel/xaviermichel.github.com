//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Pion.hpp"

#include "ObjectFactory.hpp"

#include "Projectile.hpp"
#include "ImageManager.hpp"

using namespace sf;

Pion::Pion(Monde *monde, const sf::Vector2f &position, const sf::Vector2f &taillePion, const std::string &arme, const float vitesse)
    : ObjetMonde(monde, position, taillePion, ImageManager::getImgAnim("personnage"), TYPE_PION, 0),
    m_armeManager(arme), m_vitesse(vitesse)
{
}

void Pion::tirer(const Vector2f &cible) {
    m_armeManager.demanderTir(m_monde, this, cible);
}

void Pion::deplacer(const DIRECTION d) {

    setAnimationRow(d);

    if (
            d == HAUT
            && m_position.y - m_taille.y/2 - m_vitesse > 0
            && ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y - m_vitesse - m_taille.y/2) == couleurLibre
            ) {
        m_position.y -= m_vitesse;
    }
    else if (
            d == BAS
            && m_position.y + m_vitesse + m_taille.y/2 < ImageManager::getImage("collision")->GetHeight()
            && ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y + m_vitesse + m_taille.y/2) == couleurLibre
            ) {
        m_position.y += m_vitesse;
    }
    else if ( d == GAUCHE
              && m_position.x - m_vitesse - m_taille.x/2 > 0
              && ImageManager::getImage("collision")->GetPixel(m_position.x - m_vitesse - m_taille.x/2, m_position.y) == couleurLibre
              ) {
       m_position.x -= m_vitesse;
    }
    else if ( d == DROITE
              && m_position.x + m_vitesse + m_taille.x/2 < ImageManager::getImage("collision")->GetWidth()
              && ImageManager::getImage("collision")->GetPixel(m_position.x + m_vitesse + m_taille.x/2, m_position.y) == couleurLibre
              ) {
        m_position.x += m_vitesse;
    }
}

void Pion::nextWeapon() {
    m_armeManager.nextWeapon();
}

void Pion::previousWeapon() {
    m_armeManager.previousWeapon();
}

void Pion::addWeapon(const std::string &arme) {
    m_armeManager.addWeapon(arme);
}

void Pion::removeWeapon(const std::string &arme) {
    m_armeManager.removeWeapon(arme);
}

const std::string & Pion::currentWeapon() const {
    return m_armeManager.currentWeapon();
}

float Pion::getVitesse() const {
    return m_vitesse;
}
