//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Joueur.hpp"

#include "Monde.hpp"

using namespace sf;

Joueur::Joueur(Monde *monde, const sf::Vector2f &position, const sf::Vector2f &taillePion)
    : Pion(monde, position, taillePion, "shuriken", /*vitesse = */ 2.5f), m_armeManagerUI(&m_armeManager) {

    addWeapon("rocket");

    m_armeManagerUI.update();
}


void Joueur::update() {
}


void Joueur::Render(sf::RenderTarget &Target) const {
    ObjetMonde::Render(Target);
    m_armeManagerUI.dessiner(Target);
}



void Joueur::nextWeapon() {
    Pion::nextWeapon();
    m_armeManagerUI.update();
}

void Joueur::previousWeapon() {
    Pion::previousWeapon();
    m_armeManagerUI.update();
}

void Joueur::addWeapon(const std::string &arme) {
    Pion::addWeapon(arme);
    m_armeManagerUI.update();
}

void Joueur::removeWeapon(const std::string &arme) {
    Pion::removeWeapon(arme);
    m_armeManagerUI.update();
}
