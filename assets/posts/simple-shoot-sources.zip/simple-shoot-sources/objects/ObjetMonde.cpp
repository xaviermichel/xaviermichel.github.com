//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ObjetMonde.hpp"

#include "Monde.hpp"

#include "SoundManager.hpp"
#include "ImageManager.hpp"
#include "ObjectFactory.hpp"


ObjetMonde::ObjetMonde(Monde *monde, const sf::Vector2f &position, const sf::Vector2f &taille, ImgAnim *anim, TYPE_OBJET type, ObjectData *objectData)
    : m_position(position), m_aDetruire(false), m_monde(monde), m_taille(taille), m_anim(anim), m_type(type), m_objectData(objectData) {
    m_anim->Resize(m_taille);
    m_anim->SetCenter(m_taille.x/2, m_taille.y/2);
}



ObjetMonde::~ObjetMonde() {
    delete m_anim;
}


void ObjetMonde::Render(sf::RenderTarget& Target) const {
    m_anim->setPosition(m_position.x, m_position.y);
    Target.Draw(*m_anim);
}


bool ObjetMonde::aDetruire() const {
    return m_aDetruire;
}



void ObjetMonde::setAnimationRow(const int row) {
    if ( m_anim ) {
        if ( row == -1 ) {
            m_anim->stop();
        } else {
            m_anim->setAnimRow(row);
            m_anim->play();
        }
    }
}


void ObjetMonde::setADetruire() {
    m_aDetruire = true;
}



const sf::Vector2f & ObjetMonde::getPosition() const {
    return m_position;
}

const sf::Vector2f & ObjetMonde::getTaille() const {
    return m_taille;
}

void ObjetMonde::playAnim() {
    m_anim->play();
}

TYPE_OBJET ObjetMonde::getType() const {
    return m_type;
}

bool ObjetMonde::hitTest(sf::Vector2f const &point, const unsigned short int alpha) const {

    sf::Vector2f pointT = m_anim->TransformToLocal(point);

    if (pointT.x <= 0)
        return false;
    else if (pointT.x >= m_anim->GetSubRect().GetWidth())
        return false;
    else if (pointT.y <= 0)
        return false;
    else if (pointT.y >= m_anim->GetSubRect().GetHeight())
        return false;

    return (m_anim->GetPixel(pointT.x + m_anim->GetSubRect().Left,
                            pointT.y + m_anim->GetSubRect().Top)).a >= alpha;
}


void ObjetMonde::actionAvantDestruction() {

    if ( m_type == TYPE_PION ) {    // les pions ne sont pas (encore ?) géré par l'usine d'objet, et n'ont pas (encore ?) d'objectData
        return;
    }

    std::pair< std::multimap< std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator> it;

    // éphémères
    if ( m_objectData->ephemerals.count("onDestroy") > 0 ) {
        it = m_objectData->ephemerals.equal_range("onDestroy");

        std::vector<std::string> ephemeresPossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
            ephemeresPossible.push_back( (*it2).second );
        }

        m_monde->ajouterObjetMonde(
                    ObjectFactory::createEphemere(
                        ephemeresPossible[sf::Randomizer::Random(0, ephemeresPossible.size()-1)],
                        m_monde,
                        m_position
                    )
       );
    }

    // sons
    if ( m_objectData->sounds.count("onDestroy") > 0 ) {
        it = m_objectData->sounds.equal_range("onDestroy");

        std::vector<std::string> sonsPossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
            sonsPossible.push_back( (*it2).second );
        }

        SoundManager::playSound(sonsPossible[sf::Randomizer::Random(0, sonsPossible.size()-1)]);
    }

}

