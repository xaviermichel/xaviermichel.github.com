//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef OBJET_MONDE_HPP
#define OBJET_MONDE_HPP

#include "constantes.hpp"

#include "ImgAnim.hpp"

class Monde;
struct ObjectData;


/*!
    \enum TYPE_OBJET
    \brief Le type d'objet, dans les grandes catégories
    La valeur associé sert de z-index pour le tracé.
*/
enum TYPE_OBJET {
    TYPE_PION       = 10,       //!< Un pion
    TYPE_PROJECTILE = 20,       //!< Un projectile
    TYPE_EPHEMERE   = 30        //!< Un éphémère
};


/*!
    \class ObjetMonde
    \brief Un objet du monde, typiquement, on a ici les pions et les missiles
*/
class ObjetMonde : public sf::Drawable {

public :

        /*!
            \param monde Le monde dans lequel évolue l'objet
            \param position La position initiale de l'objet
            \param taille La taille de l'objet
            \param type Le type d'objet que je serai
            \param objectData Les données attachées à cet objet
        */
        ObjetMonde(
                Monde *monde,
                const sf::Vector2f &position,
                const sf::Vector2f &taille,
                ImgAnim *anim,
                TYPE_OBJET type,
                ObjectData *objectData
        );


        /*!
            \brief Un destructeur à surcharger
        */
        virtual ~ObjetMonde();

        /*!
            \brief Mise à jour de l'affichage
        */
        virtual void Render(sf::RenderTarget& Target) const;

        /*!
            \return La position de l'objet (la position du centre de sa représentation graphique)
        */
        const sf::Vector2f & getPosition() const;

        /*!
            \return La taille de l'objet
        */
        const sf::Vector2f & getTaille() const;

        /*!
           \brief Cet objet a-t-il terminé son travail, est-il à détruire ?
           \return Vrai si l'objet est effectivement à détruire
        */
        virtual bool aDetruire() const;

        /*!
            \brief Force l'ordre de destruction de l'objet
        */
        void setADetruire();

        /*!
            \brief Mise à jour du Pion
            Par exemple pour l'IA il s'agira de se déplacer, de tirer...
        */
        virtual void update() = 0;


        /*!
            \brief Fixe la ligne d'animation à jouer
            Si on envoie -1 en paramètre, l'animation s'arrête
        */
        void setAnimationRow(const int row);

        /*!
            \brief Force l'objet à lancer son animation
        */
        void playAnim();

        /*!
            \brief Test de colision
            \see http://www.sfml-dev.org/wiki/fr/sources/hit_test
            Cette méthode test si un clic souris a été fait dans un
            sprite, qu'il soit droit ou incliné.
            Ce test est effectif pour n'importe quel angle de rotation.
            Si la transparence du pixel est sous le seuil fixé, le test
            retourne faux. Le seuil valant de 0 à 255.
        */
        bool hitTest(sf::Vector2f const & point, const unsigned short int alpha = 0) const;

        /*!
            \brief Quel est le type de l'objet ?
        */
        TYPE_OBJET getType() const;

        /*!
            \brief Dit à l'objet de balancer son animation de fin, et son son de destruction par exemple
        */
        virtual void actionAvantDestruction();


protected :

        sf::Vector2f m_position;        //!< La position de l'objet

        bool m_aDetruire;               //!< Cet objet est-il maintenant à détruire ?

        Monde *m_monde;                 //!< Le monde dans lequel évolue l'objet

        sf::Vector2f m_taille;          //!< La taille de l'objet

        mutable ImgAnim *m_anim;        //!< Animation de l'objet

        TYPE_OBJET m_type;              //!< De quel type d'objet suis-je ?

        ObjectData *m_objectData;      //!< Mes données
};


/*!
    \struct TrieSelonZValue
    \brief foncteur de trie pour dessiner les objets dans le bon ordre
*/
struct TrieSelonZValue {
    bool operator() (const ObjetMonde *om1, const ObjetMonde *om2) const {
        return om1->getType() < om2->getType();
    }
};


#endif // OBJET_MONDE_HPP

