//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ObjectFactory.hpp"

#include "Parametres.hpp"

#include "Monde.hpp"
#include "Projectile.hpp"
#include "Pion.hpp"
#include "Ephemere.hpp"

#include "SoundManager.hpp"
#include "ImageManager.hpp"

#include "tinyxml.h"


ObjectFactory::ObjectFactory() {

    TiXmlDocument objectsDoc(DATA"/objects.xml");
    if( ! objectsDoc.LoadFile() ){
        std::cerr << "erreur lors du chargement de objects.xml" << std::endl;
        std::cerr << "error #" << objectsDoc.ErrorId() << " : " << objectsDoc.ErrorDesc() << std::endl;
        exit(0);
    }

    TiXmlHandle hdl(&objectsDoc);

    TiXmlElement *elemWeapons = hdl.FirstChildElement().FirstChildElement("weapons").Element()->FirstChildElement();

    // chargement des données sur les armes
    while( elemWeapons ) {

        ObjectData *od = new ObjectData;
        od->type = TYPE_PROJECTILE;
        od->height = atof(elemWeapons->Attribute("height"));
        od->width = atof(elemWeapons->Attribute("width"));
        od->weaponData.speed = atof(elemWeapons->Attribute("speed"));
        od->weaponData.reload = atof(elemWeapons->Attribute("reload"));
        od->weaponData.uiImage = new char[strlen(elemWeapons->Attribute("ui")) + 1];
        strcpy(od->weaponData.uiImage, elemWeapons->Attribute("ui"));
        od->weaponData.mouseImage = new char[strlen(elemWeapons->Attribute("mouse")) + 1];
        strcpy(od->weaponData.mouseImage, elemWeapons->Attribute("mouse"));

        TiXmlElement *elemImages = elemWeapons->FirstChildElement("images")->FirstChildElement();
        while ( elemImages ) {
            od->images.insert(std::pair<std::string, std::string>(elemImages->Attribute("triggered"), elemImages->Attribute("name")));
            elemImages = elemImages->NextSiblingElement();
        }
        TiXmlElement *elemSounds = elemWeapons->FirstChildElement("sounds")->FirstChildElement();
        while ( elemSounds ) {
            od->sounds.insert(std::pair<std::string, std::string>(elemSounds->Attribute("triggered"), elemSounds->Attribute("name")));

            if ( elemSounds->Attribute("condition") ) {  // à faire seulement si
                od->conditions.insert(
                        std::pair< std::pair<std::string, std::string>, std::string >
                        (std::pair<std::string, std::string>(elemSounds->Attribute("triggered"), elemSounds->Attribute("name")),
                         elemSounds->Attribute("condition")));
            }

            elemSounds = elemSounds->NextSiblingElement();
        }
        TiXmlElement *elemEphemeral = elemWeapons->FirstChildElement("ephemerals")->FirstChildElement();
        while ( elemEphemeral ) {
            od->ephemerals.insert(std::pair<std::string, std::string>(elemEphemeral->Attribute("triggered"), elemEphemeral->Attribute("name")));

            if ( elemEphemeral->Attribute("condition") ) {  // à faire seulement si
                od->conditions.insert(
                        std::pair< std::pair<std::string, std::string>, std::string >
                        (std::pair<std::string, std::string>(elemEphemeral->Attribute("triggered"), elemEphemeral->Attribute("name")),
                         elemEphemeral->Attribute("condition")));
            }

            elemEphemeral = elemEphemeral->NextSiblingElement();
        }

        m_ressources[elemWeapons->Attribute("name")] = od;
        elemWeapons = elemWeapons->NextSiblingElement();
    }


    TiXmlElement *elemEphemerals = hdl.FirstChildElement().FirstChildElement("ephemerals").Element()->FirstChildElement();

    // chargement des données sur les éphémères
    while( elemEphemerals ) {

        ObjectData *od = new ObjectData;
        od->type = TYPE_EPHEMERE;
        od->height = atof(elemEphemerals->Attribute("height"));
        od->width = atof(elemEphemerals->Attribute("width"));

        TiXmlElement *elemImages = elemEphemerals->FirstChildElement("images")->FirstChildElement();
        while ( elemImages ) {
            od->images.insert(std::pair<std::string, std::string>(elemImages->Attribute("triggered"), elemImages->Attribute("name")));
            elemImages = elemImages->NextSiblingElement();
        }
        TiXmlElement *elemSounds = elemEphemerals->FirstChildElement("sounds")->FirstChildElement();
        while ( elemSounds ) {
            od->sounds.insert(std::pair<std::string, std::string>(elemSounds->Attribute("triggered"), elemSounds->Attribute("name")));
            elemSounds = elemSounds->NextSiblingElement();
        }
        TiXmlElement *elemEphemeral = elemEphemerals->FirstChildElement("ephemerals")->FirstChildElement();
        while ( elemEphemeral ) {
            od->ephemerals.insert(std::pair<std::string, std::string>(elemEphemeral->Attribute("triggered"), elemEphemeral->Attribute("name")));
            elemEphemeral = elemEphemeral->NextSiblingElement();
        }

        m_ressources[elemEphemerals->Attribute("name")] = od;
        elemEphemerals = elemEphemerals->NextSiblingElement();
    }
}


ObjectFactory::~ObjectFactory() {

    for (std::map<std::string, ObjectData *>::iterator it = m_ressources.begin(); it != m_ressources.end(); ++it) {
        if ( it->second->type == TYPE_PROJECTILE ) {
            delete it->second->weaponData.uiImage;
            delete it->second->weaponData.mouseImage;
        }
        delete it->second;
    }
    m_ressources.clear();

}


ObjetMonde* ObjectFactory::createEphemere(const std::string &name, Monde *m, const sf::Vector2f &position) {

    ObjectFactory *of = ObjectFactory::getInstance();
    ObjectData *od = of->m_ressources[name];

    std::pair< std::multimap< std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator> it;

    if ( od && od->type == TYPE_EPHEMERE &&  od->sounds.count("onCreate") > 0 ) {
            it = od->sounds.equal_range("onCreate");

            std::vector<std::string> sonsPossible;
            for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
                   sonsPossible.push_back( (*it2).second );
            }

            SoundManager::playSound(sonsPossible[sf::Randomizer::Random(0, sonsPossible.size()-1)]);

        if ( od->ephemerals.count("onCreate") > 0 ) {
            it = od->ephemerals.equal_range("onCreate");

            std::vector<std::string> ephemeresPossible;
            for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
                   ephemeresPossible.push_back( (*it2).second );
            }
            m->ajouterObjetMonde( ObjectFactory::createEphemere(ephemeresPossible[sf::Randomizer::Random(0, ephemeresPossible.size() - 1)], m, position) );
        }

     }

    if ( od->images.count("onCreate") > 0 ) {

        it = od->images.equal_range("onCreate");

        std::vector<std::string> imagePossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
               imagePossible.push_back( (*it2).second );
        }

        ObjetMonde *om = new Ephemere(
                                m,
                                position, sf::Vector2f(od->width, od->height),
                                ImageManager::getImgAnim(imagePossible[sf::Randomizer::Random(0, imagePossible.size()-1)]),
                                od
                            );
        return om;
    }
    else {
        std::cerr << "Erreur ObjectFactory::createEphemere, le type d'objet est invalide : " << name << std::endl;
    }
}


ObjetMonde* ObjectFactory::createProjectile(const std::string &name, Monde *m, const Pion *tireur, const sf::Vector2f &cible) {

    ObjectFactory *of = ObjectFactory::getInstance();
    ObjectData *od = of->m_ressources[name];

    if ( od && od->type == TYPE_PROJECTILE && od->images.count("onCreate") > 0 ) {
        std::pair< std::multimap< std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator> it;
        it = od->images.equal_range("onCreate");

        std::vector<std::string> imagePossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
               imagePossible.push_back( (*it2).second );
        }

        ObjetMonde *om = new Projectile(
                                m,
                                tireur,
                                cible,
                                od->weaponData.speed,
                                sf::Vector2f(od->width, od->height),
                                ImageManager::getImgAnim(imagePossible[sf::Randomizer::Random(0, imagePossible.size()-1)]),
                                od
                         );

        if ( od->sounds.count("onCreate") > 0 ) {
            it = od->sounds.equal_range("onCreate");

            std::vector<std::string> sonsPossible;
            for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
                   sonsPossible.push_back( (*it2).second );
            }

            SoundManager::playSound(sonsPossible[sf::Randomizer::Random(0, sonsPossible.size()-1)]);
        }

        if ( od->ephemerals.count("onCreate") > 0 ) {
            it = od->ephemerals.equal_range("onCreate");

            std::vector<std::string> ephemeresPossible;
            for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
                   ephemeresPossible.push_back( (*it2).second );
            }
            m->ajouterObjetMonde( ObjectFactory::createEphemere(ephemeresPossible[sf::Randomizer::Random(0, ephemeresPossible.size() - 1)], m, om->getPosition()) );
        }

        return om;

    } else {
        std::cerr << "Erreur ObjectFactory::createProjectile, le type d'objet est invalide : " << name << std::endl;
    }
}


const WeaponsData& ObjectFactory::getWeaponData(const std::string &arme) {
    ObjectData *od = ObjectFactory::getInstance()->m_ressources[arme];
    if ( od ) {
        return od->weaponData;
    } else {
        std::cerr << "Erreur ObjectFactory::getWeaponData : arme incorrecte : " << arme << std::endl;
    }
}

