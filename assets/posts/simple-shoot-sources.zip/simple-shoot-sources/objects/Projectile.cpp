//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Projectile.hpp"

#include "IA.hpp"
#include "Pion.hpp"
#include "Monde.hpp"

#include "ObjectFactory.hpp"
#include "ImageManager.hpp"
#include "SoundManager.hpp"

using namespace sf;


Projectile::Projectile(Monde *monde, const Pion *tireur, const Vector2f &cible, const float vitesseMissile, const sf::Vector2f &tailleMissile, ImgAnim *anim, ObjectData *objectData)
    : ObjetMonde(monde, tireur->getPosition(), tailleMissile, anim, TYPE_PROJECTILE, objectData),
    m_tireur(tireur), m_simulation(false), m_vitesseMissile(vitesseMissile)
{
    m_position = tireur->getPosition();

    // k est la distance du segment départ, cible
    float k = std::sqrt(
            (cible.y - m_position.y) * (cible.y - m_position.y) +
            (cible.x - m_position.x) * (cible.x - m_position.x)
            );

    // calcul des delta : application directe du théorème de Thalès... ça ressort de loin tout ça !
    float deltaX = ((cible.x - m_position.x) * m_vitesseMissile) / k;
    float deltaY = ((cible.y - m_position.y) * m_vitesseMissile) / k;

    m_vecteurDeplacement = Vector2f(deltaX, deltaY);

    // un missile qui ne bouge pas est mort
    m_aDetruire = ( m_vecteurDeplacement == Vector2f(0, 0) );

    // tourner le missile dans la bonne direction
    float angle = 180 * std::atan( (cible.x - m_position.x) / (cible.y - m_position.y) ) / PI;
    if ( (cible.y - m_position.y) >= 0 ) {
        angle = 180+angle;
    }
    m_anim->SetRotation(angle);

}


void Projectile::update() {

    m_position += m_vecteurDeplacement;

    if ( m_position.x < m_taille.x/2 || m_position.x > ImageManager::getImage("collision")->GetWidth() - m_taille.x/2 || m_position.y < m_taille.y/2
         || m_position.y > ImageManager::getImage("collision")->GetHeight() - m_taille.y/2 ) {
        m_aDetruire = true;
        m_death = OUT_OF_MAP;
        return;
    }

    if ( ImageManager::getImage("collision")->GetPixel(m_position.x, m_position.y) == couleurMur) {
        m_aDetruire = true;
        m_death = REACH_OBSTACLE;
        return;
    }

    for (std::vector<ObjetMonde*>::const_iterator it = m_monde->getVObjetMonde().begin(); it != m_monde->getVObjetMonde().end(); ++it ) {

        if ( (*it)->getType() == TYPE_PION ) { // seul les collisions entre moi (projectile) et un pion compte, mais on pourrait gérer les collisions entre projectiles ici

            if ( touchePion( static_cast<Pion *>(*it) ) ) {
                if ( ! m_simulation ) {
                    (*it)->setADetruire();
                }
                m_death = KILLED_SOMEONE;
                m_aDetruire = true;
                return;
            }
        }

    }

}



bool Projectile::simulerTir(const Pion *joueur) {

    m_simulation = true;
    while ( ! m_aDetruire ) {
        update();
    }

    m_aDetruire = false;
    m_simulation = false;

    return touchePion(joueur);
}



bool Projectile::vaBientotToucher(const Pion *cible) {

    Vector2f savePostion = m_position;

    m_simulation = true;
    for (uchar i=0; i < ((IA*)(cible))->getNombreTourSimulation() && ! m_aDetruire; ++i) {
        update();
    }

    m_aDetruire = false;
    m_simulation = false;

    // le touchera-t-on ?
    bool ret = touchePion(cible);

    // ce n'était qu'une simulation, revenons où nous étions
    m_position = savePostion;

    return ret;
}



const Pion * Projectile::getTireur() const {
    return m_tireur;
}


const sf::Vector2f & Projectile::getDeplacement() const {
    return m_vecteurDeplacement;
}


bool Projectile::touchePion(const Pion *p) const {

    return (
                ( m_tireur != p ) && (
                        p->hitTest(Vector2f(m_position.x, m_position.y))
                     || p->hitTest(Vector2f(m_position.x-m_taille.x/2, m_position.y-m_taille.y/2))
                     || p->hitTest(Vector2f(m_position.x+m_taille.x/2, m_position.y-m_taille.y/2))
                     || p->hitTest(Vector2f(m_position.x+m_taille.x/2, m_position.y+m_taille.y/2))
                     || p->hitTest(Vector2f(m_position.x-m_taille.x/2, m_position.y+m_taille.y/2))
                )
            );

}



void Projectile::actionAvantDestruction() {

    std::pair< std::multimap< std::string, std::string>::iterator, std::multimap<std::string, std::string>::iterator > it;

    // les éphémères
    if ( m_objectData->ephemerals.count("onDestroy") > 0 ) {
        it = m_objectData->ephemerals.equal_range("onDestroy");

        std::vector<std::string> ephemeresPossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
            ephemeresPossible.push_back( (*it2).second );
        }

        // avec condition
        std::pair< std::multimap< std::pair<std::string, std::string>, std::string>::iterator, std::multimap< std::pair<std::string, std::string>, std::string>::iterator > itCondition;
        for (std::vector<std::string>::iterator it2 = ephemeresPossible.begin(); it2 != ephemeresPossible.end(); ) {
            itCondition = m_objectData->conditions.equal_range(std::pair<std::string, std::string> (std::pair<std::string, std::string>("onDestroy", *it2)));

            bool toDelete = false;
            for (std::multimap<std::pair<std::string, std::string>, std::string>::iterator it3 = itCondition.first; it3 != itCondition.second; ++it3) {

                // je n'ai tué personne, mais il fallait le faire pour lancer l'anim
                if ( m_death != KILLED_SOMEONE && it3->second == "hasKilledSomeone" ) {
                    toDelete = true;
                }

                // j'ai tué quelqu'un, mais il ne fallait pas pour lancer l'anim
                if ( m_death == KILLED_SOMEONE && it3->second == "notHasKilledSomeone" ) {
                    toDelete = true;
                }

            }
            if ( toDelete ) {
                it2 = ephemeresPossible.erase(it2);
            } else {
                ++it2;
            }
        }

        if ( ephemeresPossible.size() > 0 ) {
            m_monde->ajouterObjetMonde(
                        ObjectFactory::createEphemere(
                            ephemeresPossible[sf::Randomizer::Random(0, ephemeresPossible.size()-1)],
                            m_monde,
                            m_position
                        )
           );
        }
    }


    // les sons
    if ( m_objectData->sounds.count("onDestroy") > 0 ) {
        it = m_objectData->sounds.equal_range("onDestroy");

        std::vector<std::string> sonsPossible;
        for (std::multimap<std::string, std::string>::iterator it2 = it.first; it2 != it.second; ++it2) {
            sonsPossible.push_back( (*it2).second );
        }

        // avec condition
        std::pair< std::multimap< std::pair<std::string, std::string>, std::string>::iterator, std::multimap< std::pair<std::string, std::string>, std::string>::iterator > itCondition;
        for (std::vector<std::string>::iterator it2 = sonsPossible.begin(); it2 != sonsPossible.end(); ) {
            itCondition = m_objectData->conditions.equal_range(std::pair<std::string, std::string> (std::pair<std::string, std::string>("onDestroy", *it2)));

            bool toDelete = false;
            for (std::multimap<std::pair<std::string, std::string>, std::string>::iterator it3 = itCondition.first; it3 != itCondition.second; ++it3) {

                // je n'ai tué personne, mais il fallait le faire pour lancer le son
                if ( m_death != KILLED_SOMEONE && it3->second == "hasKilledSomeone" ) {
                    toDelete = true;
                }

                // j'ai tué quelqu'un, mais il ne fallait pas pour lancer le son
                if ( m_death == KILLED_SOMEONE && it3->second == "notHasKilledSomeone" ) {
                    toDelete = true;
                }

            }
            if ( toDelete ) {
                it2 = sonsPossible.erase(it2);
            } else {
                ++it2;
            }
        }

        if ( sonsPossible.size() > 0 ) {
            SoundManager::playSound(sonsPossible[sf::Randomizer::Random(0, sonsPossible.size()-1)]);
        }
    }


}

