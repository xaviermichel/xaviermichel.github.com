//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ArmeManager.hpp"

#include "ObjectFactory.hpp"

#include "Monde.hpp"
#include "Pion.hpp"

sf::Clock ArmeManager::am_clock;

ArmeManager::ArmeManager(const std::string &armeInitiale)
    : m_current_weapon(armeInitiale)
{
    addWeapon(armeInitiale);
    m_timeSwapWeapon.Reset();
}


const std::string& ArmeManager::currentWeapon() const {
    return m_current_weapon;
}


void ArmeManager::nextWeapon() {

    if ( m_timeSwapWeapon.GetElapsedTime() < tempsChangementArme ) {
        return;
    }
    m_timeSwapWeapon.Reset();

    std::vector<std::string>::iterator it = find(m_mesArmes.begin(), m_mesArmes.end(), m_current_weapon);
    ++it;
    if ( it == m_mesArmes.end() ) {
        it = m_mesArmes.begin();
    }
    m_current_weapon = *it;
}

void ArmeManager::previousWeapon() {

    if ( m_timeSwapWeapon.GetElapsedTime() < tempsChangementArme ) {
        return;
    }
    m_timeSwapWeapon.Reset();

    std::vector<std::string>::iterator it = find(m_mesArmes.begin(), m_mesArmes.end(), m_current_weapon);
    if ( it == m_mesArmes.begin() ) {
        m_current_weapon = m_mesArmes.back();
    } else {
        m_current_weapon = *m_mesArmes.begin();
    }
}

void ArmeManager::addWeapon(const std::string &arme) {
    std::vector<std::string>::iterator it = find(m_mesArmes.begin(), m_mesArmes.end(), arme);
    if ( it == m_mesArmes.end() ) { // on ne l'a pas encore
        m_mesArmes.push_back(arme);
        m_tempsDeRecharges[arme] = 0.f;
    }
}

void ArmeManager::removeWeapon(const std::string &arme) {
    std::vector<std::string>::iterator it = find(m_mesArmes.begin(), m_mesArmes.end(), arme);

    // si je veux supprimer mon arme courante, ais-je les moyens d'en prendre une autre ?
    if ( *it == m_current_weapon && m_mesArmes.size() > 1 ) {
        nextWeapon();
        m_mesArmes.erase(it);
    }

}

void ArmeManager::demanderTir(Monde *monde, Pion *p, const sf::Vector2f &cible) {


    if ( am_clock.GetElapsedTime() - m_tempsDeRecharges[m_current_weapon] > ObjectFactory::getWeaponData(m_current_weapon).reload ) {
        monde->ajouterObjetMonde(ObjectFactory::createProjectile(m_current_weapon, monde, p, cible));
        m_tempsDeRecharges[m_current_weapon] = am_clock.GetElapsedTime();
    }

}

const std::vector<std::string>& ArmeManager::getWeaponList() const {
    return m_mesArmes;
}
