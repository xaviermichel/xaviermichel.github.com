//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ArmeManagerUI.hpp"

#include "ImageManager.hpp"
#include "ArmeManager.hpp"
#include "Joueur.hpp"

#include "ObjectFactory.hpp"

ArmeManagerUI::ArmeManagerUI(ArmeManager *am)
    : m_armeManager(am)
{
}

ArmeManagerUI::~ArmeManagerUI() {
    viderSpriteList();
}

void ArmeManagerUI::viderSpriteList() {
    for ( std::vector<sf::Sprite *>::iterator it = m_spriteList.begin(); it != m_spriteList.end(); ++it) {
        delete *it;
    }
    m_spriteList.clear();
}

void ArmeManagerUI::update() {
    viderSpriteList();

    std::vector<std::string> weaponList = m_armeManager->getWeaponList();
    uchar i = 0;
    for (std::vector<std::string>::const_iterator it = weaponList.begin(); it != weaponList.end(); ++it) {
        sf::Sprite *s = new sf::Sprite(*ImageManager::getImage(ObjectFactory::getWeaponData(*it).uiImage));
        s->SetPosition(320 + 40 * i, 10);  // positionnement

        if ( *it != m_armeManager->currentWeapon() ) { // arme non-sélectionnée = réduite + transparence
            //s->Scale(0.5, 0.5);
            s->SetColor(sf::Color(255, 255, 255, 50));
        }
        m_spriteList.push_back(s);
        ++i;
    }
}

void ArmeManagerUI::dessiner(sf::RenderTarget &Target) const {
    for (std::vector<sf::Sprite *>::const_iterator it = m_spriteList.begin(); it != m_spriteList.end(); ++it) {
        Target.Draw(**it);
    }
}
