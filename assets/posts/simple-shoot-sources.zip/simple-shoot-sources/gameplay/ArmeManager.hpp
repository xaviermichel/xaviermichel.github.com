//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef ARME_MANAGER_HPP
#define ARME_MANAGER_HPP

#include "constantes.hpp"

#include "PausableClock.hpp"

class Monde;
class Pion;

/*!
    \class ArmeManager
    \brief Cela correspond à la liste des armes que possède un personnage
*/

class ArmeManager
{

public :

        /*!
            \param armeInitiale L'arme que le pion a initialement
        */
        explicit ArmeManager(const std::string &armeInitiale);

        /*!
            \brief Renvoie l'arme courante que le pion utilise
        */
        const std::string& currentWeapon() const;

        /*!
            \brief Ajoute une arme au pion
        */
        void addWeapon(const std::string &arme);

        /*!
            \brief Enleve une arme au pion
        */
        void removeWeapon(const std::string &arme);

        /*!
            \brief Ordonne au pion de selectionner l'arme suivante
        */
        void nextWeapon();

        /*!
            \brief Ordonne au pion de selectionner l'arme précédente
        */
        void previousWeapon();

        /*!
            \brief Un pion demande un tir
            \param monde Le monde dans lequel on veut tirer
            \param p Le pion qui va tirer
            \param cible Le point cible du tir
            Si le tir est autorisé, le projectile est créé dans le monde, sinon rien !
        */
        void demanderTir(Monde *monde, Pion *p, const sf::Vector2f &cible);

        /*!
            \brief Obtient la liste des armes misent à disposition du pion
        */
        const std::vector<std::string>& getWeaponList() const;


protected :

        std::vector<std::string> m_mesArmes;                    //!< La liste des armes que je possède

        std::string m_current_weapon;                           //!< L'arme que j'utilise

        PausableClock m_timeSwapWeapon;                         //!< Le temps qu'il faut pour changer d'arme

        std::map<std::string, float> m_tempsDeRecharges;        //!< Pour chaque arme, quand on a fait le dernier tir pour savoir si l'on peut s'en servir à nouveau


private :

        static sf::Clock am_clock;                              //!< Une seule horloge pour tous les manager d'armes

};

#endif
