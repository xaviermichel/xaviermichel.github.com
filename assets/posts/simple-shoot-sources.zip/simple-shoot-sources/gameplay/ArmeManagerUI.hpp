//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef ARMEMANAGERUI_HPP
#define ARMEMANAGERUI_HPP

#include "constantes.hpp"

class ArmeManager;
class Joueur;

/*!
    \class ArmeManagerUI
    \brief L'interface graphique qui représente les armes que j'ai
*/

class ArmeManagerUI
{

public:
        /*!
            \param am L'arme manager que je vais représenter
        */
        ArmeManagerUI(ArmeManager *am);

        ~ArmeManagerUI();

        /*!
            \brief Dessiner les armes à l'écran
            \param Target La fenêtre sur laquelle je dois me dessiner
        */
        void dessiner(sf::RenderTarget &Target) const;


        /*!
            \brief Mise à jour de mes sprites
        */
        void update();


private :

        /*!
            \brief Vider la liste de mes sprites
        */
        void viderSpriteList();


protected :

        ArmeManager *m_armeManager;                     //!< L'arme manager que je vais représenter

        std::vector<sf::Sprite *> m_spriteList;         //!< Ma liste de sprites à dessiner

};




#endif // ARMEMANAGERUI_HPP
