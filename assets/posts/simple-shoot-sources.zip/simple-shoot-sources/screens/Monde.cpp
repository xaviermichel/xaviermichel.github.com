//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Monde.hpp"

#include "ScoreInput.hpp"

#include "ObjetMonde.hpp"
#include "ObjectFactory.hpp"

#include "ImageManager.hpp"
#include "SoundManager.hpp"
#include "Parametres.hpp"

using namespace sf;

Monde::Monde() : m_scoreInput(0), m_partieTerminee(false) {
    m_clockTempsEcoule.Reset();
    m_clockApparition.Reset();

    if ( ! m_police.LoadFromFile(DATA_POLICES"aller.ttf") ) {
        std::cout << "Erreur chargement police" << std::endl;
    }
}

Monde::~Monde() {
    vider();
    ImageManager::kill();
    SoundManager::kill();
    Parametres::kill();
    ObjectFactory::kill();
}

void Monde::vider() {

    for (std::vector<ObjetMonde *>::iterator it = m_vObjetMonde.begin(); it != m_vObjetMonde.end(); ++it) {
        delete *it;
    }
    m_vObjetMonde.clear();

    for (std::vector<ObjetMonde *>::iterator it = m_vObjetMondeEnAttente.begin(); it != m_vObjetMondeEnAttente.end(); ++it) {
        delete *it;
    }
    m_vObjetMondeEnAttente.clear();

    m_pionJoueur = 0;

    if ( m_scoreInput ) {
        delete m_scoreInput;
    }
    m_scoreInput = 0;
}


int Monde::Run(sf::RenderWindow &App) {

    Sprite carte(*ImageManager::getImage("fond"));

    Sprite spriteMute(*ImageManager::getImage("notMute"));
    spriteMute.Resize(30, 30);
    spriteMute.SetPosition(450, 10);

    sf::String stringTemps("", m_police, 18); // temps écoulé
    stringTemps.SetColor(sf::Color::Black);
    stringTemps.SetPosition(310, 50);

    // je dois le gérer ici car la gui récupéré n'est pas finalisé,
    // et comporte des bugs génants...
    sf::Sprite fondScoreInput(*ImageManager::getImage("fond_score_input"));
    fondScoreInput.Resize(310, 340);
    fondScoreInput.SetPosition(255, 160);

    nouvellePartie();

    Sprite viseur(*ImageManager::getImage(ObjectFactory::getWeaponData(m_pionJoueur->currentWeapon()).mouseImage));
    viseur.Resize(tailleViseur, tailleViseur);

    //m_vObjetMonde.push_back(new IA(this, Vector2f(375, 290), 1));
    //m_vObjetMonde.push_back(new IA(this, Vector2f(10, 10)));
    //m_vObjetMonde.push_back(new IA(this, Vector2f(10, 590), 3));

    while (App.IsOpened())
    {
        // Traitement des évènements
        sf::Event Event;
        while (App.GetEvent(Event))
        {
            // Fenêtre fermée : on quitte
            if (Event.Type == sf::Event::Closed) {
                App.Close();
            }

            /* // ça ça sert pour les tests
            if (Event.Type == sf::Event::MouseButtonPressed) {
                const sf::Input& input = App.GetInput();
                Vector2f mp(input.GetMouseX(), input.GetMouseY());
                std::cout << mp.x << " , " << mp.y << std::endl;
            }*/

            if ( Event.Type == sf::Event::KeyPressed ) {

                if ( Event.Key.Code == sf::Key::R && ! m_partieTerminee ) {
                    nouvellePartie();
                    viseur.SetImage(*ImageManager::getImage(ObjectFactory::getWeaponData(m_pionJoueur->currentWeapon()).mouseImage));
                }
                else if ( Event.Key.Code == sf::Key::M && ! m_partieTerminee ) {
                    Parametres::toogleSound();
                    spriteMute.SetImage(*ImageManager::getImage(Parametres::isMute() ? "mute" : "notMute"));
                }

            } else if ( Event.Type == sf::Event::MouseWheelMoved && ! m_partieTerminee ) {

                if ( Event.MouseWheel.Delta > 0 ) {
                    m_pionJoueur->nextWeapon();
                } else {
                    m_pionJoueur->previousWeapon();
                }

                viseur.SetImage(*ImageManager::getImage(ObjectFactory::getWeaponData(m_pionJoueur->currentWeapon()).mouseImage));

            }

            if ( m_partieTerminee && m_scoreInput ) {
                m_scoreInput->traiterEvenement(Event);
            }

        }

        // traiter les évenements
        const Input& input = App.GetInput();

        if ( m_partieTerminee && m_scoreInput ) {
            m_scoreInput->traiterEvenement(input);
        }

        viseur.SetPosition(input.GetMouseX() - tailleViseur/2, input.GetMouseY() - tailleViseur/2);

        if ( ! m_partieTerminee ) {

            // déplacer le joueur
            bool mouvementEnCours = false;

            if (input.IsKeyDown(sf::Key::Z)) {
                m_pionJoueur->deplacer(HAUT);
                mouvementEnCours = true;
            }
            if (input.IsKeyDown(sf::Key::S)) {
                m_pionJoueur->deplacer(BAS);
                mouvementEnCours = true;
            }
            if (input.IsKeyDown(sf::Key::Q)) {
                m_pionJoueur->deplacer(GAUCHE);
                mouvementEnCours = true;
            }
            if (input.IsKeyDown(sf::Key::D)) {
                m_pionJoueur->deplacer(DROITE);
                mouvementEnCours = true;
            }
            if (input.IsMouseButtonDown(sf::Mouse::Left)) {
                if ( m_pionJoueur ) {
                    m_pionJoueur->tirer(Vector2f(input.GetMouseX(), input.GetMouseY()));
                }
            }

            if ( ! mouvementEnCours ) {
                m_pionJoueur->setAnimationRow(-1); // fin de l'animation
            }


            // faire apparaitre des bots

            if ( m_clockApparition.GetElapsedTime() > 5 - m_clockTempsEcoule.GetElapsedTime()/30 ) { // féquence d'apparition

                Vector2f position;

                switch ( sf::Randomizer::Random(0, 3)) {
                case 0:
                    position = Vector2f(10, 10);
                    break;
                case 1:
                    position = Vector2f(10, 590);
                    break;
                case 2:
                    position = Vector2f(790, 10);
                    break;
                case 3:
                    position = Vector2f(790, 590);
                    break;
                }
                // l'IA tirera de plus en plus vite également
                float cadenceTir = 3 - m_clockTempsEcoule.GetElapsedTime()/30 + sf::Randomizer::Random(-0.5f, 0.5f);
                if ( cadenceTir < 0.4 ) { // faut pas abuser non plus
                    cadenceTir = 0.4;
                }

                m_vObjetMonde.push_back(new IA(
                                                this,
                                                position,
                                                cadenceTir,
                                                sf::Randomizer::Random(0, 1) == 1 ? "rocket" : "shuriken"  // arme
                                               )
                                        );
                m_clockApparition.Reset();
            }

        }

        if ( m_partieTerminee ) {
            m_clockTempsEcoule.Pause();
            std::ostringstream oss;
            oss << "Partie terminee : \n" << ((int)(m_clockTempsEcoule.GetElapsedTime()*100))/100. << " secondes";
            stringTemps.SetText(oss.str());

            if ( m_partieTerminee && ! m_scoreInput ) {
                m_scoreInput = new ScoreInput(App, ((int)(m_clockTempsEcoule.GetElapsedTime()*100))/100.);
            }

        } else {
            std::ostringstream oss;
            oss << "Temps : " <<  (int)m_clockTempsEcoule.GetElapsedTime() << " secondes";
            stringTemps.SetText(oss.str());
        }

        App.Clear();

        App.Draw(carte);

        App.Draw(stringTemps);
        App.Draw(spriteMute);

        for (std::vector<ObjetMonde *>::iterator it = m_vObjetMonde.begin(); it != m_vObjetMonde.end(); ) {

            //  on met à jour, les éphémères et les projectils en permanence, le reste seulement si le joueur est encore vivant
            if ( ! m_partieTerminee || (*it)->getType() == TYPE_EPHEMERE || (*it)->getType() == TYPE_PROJECTILE ) {
                (*it)->update();
            }

            if ((*it)->aDetruire()) {

                // la mort du joueur
                if ( *it == m_pionJoueur ) {
                    m_pionJoueur = 0;
                    m_partieTerminee = true;
                }

                (*it)->actionAvantDestruction();

                delete (*it);
                it = m_vObjetMonde.erase(it);
            } else {
                App.Draw(**it);
                ++it;
            }
        }

        if ( m_partieTerminee && m_scoreInput ) {
            App.Draw(fondScoreInput);
            m_scoreInput->Dessiner(App);

            if ( m_scoreInput->editionTermine() ) {
                nouvellePartie();
                viseur.SetImage(*ImageManager::getImage(ObjectFactory::getWeaponData(m_pionJoueur->currentWeapon()).mouseImage));
            }
        }

        App.Draw(viseur);

        App.Display();

        // ajout des objets en attente, on ne les a pas mis dans la foulée pour des problèmes de synchronisation !
        m_vObjetMonde.insert(m_vObjetMonde.begin(), m_vObjetMondeEnAttente.begin(), m_vObjetMondeEnAttente.end());
        m_vObjetMondeEnAttente.clear();

        // retrier en fonction de la zValue
        std::sort(m_vObjetMonde.begin(), m_vObjetMonde.end(), TrieSelonZValue());
    }

    return 0;
}


const std::vector<ObjetMonde *> & Monde::getVObjetMonde() const {
    return m_vObjetMonde;
}


const Pion * Monde::getPionJoueur() const {
    return m_pionJoueur;
}


void Monde::ajouterObjetMonde(ObjetMonde *om) {
    m_vObjetMondeEnAttente.push_back(om);
}

void Monde::nouvellePartie() {
    vider();
    m_pionJoueur = new Joueur(this, Vector2f(380, 300));
    m_vObjetMonde.push_back(m_pionJoueur);
    m_clockApparition.Reset();
    m_clockTempsEcoule.Reset();
    m_partieTerminee = false;
}
