//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef MONDE_HPP
#define MONDE_HPP

#include "constantes.hpp"

#include "Pion.hpp"
#include "Projectile.hpp"
#include "Ephemere.hpp"
#include "Joueur.hpp"
#include "IA.hpp"
#include "PausableClock.hpp"

class ScoreInput;

/*!
    \class Monde
    \brief Le monde dans lequel évoluent les pions
*/


class Monde : public sf::NonCopyable {

public:

        Monde();

        ~Monde();

        /*!
            \brief Lance le jeu
            \param App La fenêtre dans laquelle se déroule le jeu
        */
        int Run (sf::RenderWindow &App);

        /*!
            \brief Obtient le tableau des objets présents sur la carte
        */
        const std::vector<ObjetMonde *> & getVObjetMonde() const;

        /*!
            \brief Renvoie le pion contrôlé par le joueur
        */
        const Pion *getPionJoueur() const;

        /*!
            \brief Ajoutera l'objet sur le monde à la fin de la boucle principale
        */
        void ajouterObjetMonde(ObjetMonde *om);


private :

        /*!
            \brief Vidage total des vecteurs, en vue d'une nouvelle partie
        */
        void vider();

        /*!
            \brief Lance une nouvelle partie
        */
        void nouvellePartie();

protected :

        std::vector<ObjetMonde *> m_vObjetMonde;        //!< Liste des objets sur la carte

        std::vector<ObjetMonde *> m_vObjetMondeEnAttente; //!< Liste des objets à ajouter à la liste des objets sur le monde

        Joueur *m_pionJoueur;                           //!< Pion contrôlé par le joueur

        sf::Clock m_clockApparition;                    //!< Une horloge qui va servir à faire apparaitre des bot petit à petit

        PausableClock m_clockTempsEcoule;               //!< Une horloge qui compte le temps passé depuis de début du jeu

        sf::Font m_police;                              //!< La police qui va servir à afficher les messages

        ScoreInput *m_scoreInput;                       //!< Fenêtre qui demande le pseudo pour upload du score

        bool m_partieTerminee;
};


#endif // MONDE_HPP

