//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef SCOREINPUT_HPP
#define SCOREINPUT_HPP

#include "constantes.hpp"

#include "cpGUI.h"

/*!
    \class ScoreInput
    \brief La fenêtre qui demande le score pour le mettre en ligne
*/

class ScoreInput
{

public:
        /*!
            \param App La fenêtre sur laquelle on va dessiner le formulaire
            \param score Le score obtenu
            \param position Le point en haut à gauche du formulaire
        */
        ScoreInput(
                sf::RenderWindow &App,
                const float score,
                const sf::Vector2i &position = sf::Vector2i(275, 180)
        );

        ~ScoreInput();

        /*!
            \brief Dessiner le formulaire
            \param Target La fenêtre sur laquelle on dessine
        */
        void Dessiner(sf::RenderTarget& Target);

        /*!
            \brief Traiter les événements de type sf::Event
        */
        void traiterEvenement(sf::Event &event);

        /*!
            \brief Traiter les événements de type sf::Input
        */
        void traiterEvenement(const sf::Input &input);

        /*!
            \brief Renvoi vrai si le traitement est terminé
        */
        bool editionTermine() const;

private :

        /*!
            \brief Traitement des erreurs des saisies et upload du score
        */
        void soumettreScore();

        /*!
            \brief Chargement de la liste des meilleurs scores
            Appel le thread de chargement des meilleurs scores
        */
        void afficherMeilleursScores();


        /*!
            \class LoadTopTime
            \brief Le chargement des meilleurs scores dans un thread pour ne pas bloquer en cas de problème de connexion
        */
        class LoadTopTime : public sf::Thread {

        public :
                /*!
                    \param parent Papa ! Celui qui sait tout du joueur en cours (pseudo, score...)
                */
                LoadTopTime(ScoreInput *parent);

                /*!
                    \brief Lancement du thread
                */
                void Run();

        private :

                ScoreInput *m_parent;             //!< Celui qui m'a créé, et qui sait tout sur le joueur en cours

        };


protected :

        cp::cpGuiContainer *m_gui;          //!< Le contôleur principal de la gui

        cp::cpButton *m_btn_continuer;      //!< Le bouton pour annuler la saisie

        cp::cpButton *m_btn_soumettre;      //!< Le bouton pour valider la saisie

        sf::String m_str_inputLabel;        //!< Label associé à l'input

        sf::String m_str_informations;      //!< Label qui dit où on peut consulter les scores

        cp::cpTextInputBox* m_input_pseudo; //!< Entrée pour le pseudo

        bool m_editionTerminee;             //!< L'édition du formulaire est terminée ?

        float m_score;                      //!< Le score à enregistrer

        sf::Font m_police;                  //!< La police à utiliser

        sf::String m_str_best_score;        //!< Affichage des meilleurs scores

        LoadTopTime *m_threadLoadTopTime;   //!< Le thread qui va charger les meilleurs temps

};

#endif // SCOREINPUT_HPP
