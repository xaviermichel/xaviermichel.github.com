//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ScoreInput.hpp"

#include "Parametres.hpp"

ScoreInput::ScoreInput(sf::RenderWindow &App, const float score, const sf::Vector2i &position)
    : m_editionTerminee(false), m_score(score)
{

    m_gui = new cp::cpGuiContainer();

    if ( ! m_police.LoadFromFile(DATA_POLICES"aller.ttf") ) {
        std::cout << "Erreur chargement police" << std::endl;
    }

    m_str_inputLabel = sf::String("Votre pseudo :", m_police, 20);
    m_str_inputLabel.SetPosition(position.x, position.y);
    m_str_inputLabel.SetColor(sf::Color::Black);

    m_input_pseudo = new cp::cpTextInputBox(&App, m_gui, "", position.x, position.y + 30, 250, 25);
    m_input_pseudo->SetLabelText(Parametres::getPseudo());
    m_input_pseudo->SetFont(DATA_POLICES"aller.ttf", 20);

    m_str_informations = sf::String(" Les scores sont consultables sur\n"
                                    "xavier.microdev.fr/simple-shoot.php", m_police, 15);
    m_str_informations.SetPosition(position.x, position.y + 60);
    m_str_informations.SetColor(sf::Color::Black);

    m_btn_continuer = new cp::cpButton(&App, m_gui, "  Continuer\n        sans\nsauvegarder", position.x, position.y + 100);
    m_btn_continuer->SetFont(DATA_POLICES"aller.ttf", 20);
    m_btn_continuer->SetSize(120, 75);

    m_btn_soumettre = new cp::cpButton(&App, m_gui, "Soumettre\n       mon\n      score", position.x + 130, position.y + 100);
    m_btn_soumettre->SetFont(DATA_POLICES"aller.ttf", 20);
    m_btn_soumettre->SetSize(120, 75);

    m_str_best_score = sf::String("Chargement en cours...", m_police, 15);
    m_str_best_score.SetPosition(position.x, position.y + 180);
    m_str_best_score.SetColor(sf::Color::Black);

    afficherMeilleursScores();
}


ScoreInput::~ScoreInput() {

    if ( m_threadLoadTopTime ) {
        m_threadLoadTopTime->Terminate();
        delete m_threadLoadTopTime;
        m_threadLoadTopTime = 0;
    }

    delete m_btn_continuer;
    delete m_btn_soumettre;
    delete m_input_pseudo;
    delete m_gui;
}


void ScoreInput::Dessiner(sf::RenderTarget& Target) {

    m_btn_continuer->Draw();
    m_btn_soumettre->Draw();
    Target.Draw(m_str_inputLabel);
    Target.Draw(m_str_informations);
    m_input_pseudo->Draw();
    Target.Draw(m_str_best_score);

}


void ScoreInput::traiterEvenement(sf::Event &Event) {

    m_input_pseudo->ProcessTextInput(&Event);

    m_gui->ProcessKeys(&Event);
}

void ScoreInput::traiterEvenement(const sf::Input &input) {

    if(m_btn_continuer->CheckState(&input) == cp::CP_ST_MOUSE_LBUTTON_RELEASED) {
        m_editionTerminee = true;
    }


    if(m_btn_soumettre->CheckState(&input) == cp::CP_ST_MOUSE_LBUTTON_RELEASED) {
        soumettreScore();
    }

    m_input_pseudo->CheckState(&input);

}

bool ScoreInput::editionTermine() const {
    return m_editionTerminee;
}

void ScoreInput::soumettreScore() {

    if ( m_input_pseudo->GetLabelText().empty() ) {
        m_str_inputLabel.SetText("Remplissez votre pseudo");
        return;
    }

    sf::Http serveur("xavier.microdev.fr");
    sf::Http::Request requete(sf::Http::Request::Post, "simple-shoot-set-score.php");

    std::ostringstream oss;
    oss << "code="   << codeUpload
        << "&"
        << "pseudo=" << m_input_pseudo->GetLabelText()
        << "&"
        << "score="  << m_score;

    Parametres::setPseudo(m_input_pseudo->GetLabelText());

    requete.SetBody(oss.str());
    sf::Http::Response page = serveur.SendRequest(requete); // timeout

    if ( page.GetStatus() != sf::Http::Response::Ok ) {
        m_str_inputLabel.SetText("Erreur de connexion");
    } else {
        if ( page.GetBody() == "ok\n" ) {
            m_editionTerminee = true;
        } else {
            m_str_inputLabel.SetText("Code incorrect");
        }
    }
}


void ScoreInput::afficherMeilleursScores() {
    m_threadLoadTopTime = new ScoreInput::LoadTopTime(this);
    m_threadLoadTopTime->Launch();
}


/*
    Thread chargement meilleurs scores
*/


ScoreInput::LoadTopTime::LoadTopTime(ScoreInput *parent)
    : m_parent(parent)
{
}

void ScoreInput::LoadTopTime::Run() {

    sf::Http serveur("xavier.microdev.fr");
    sf::Http::Request requete(sf::Http::Request::Post, "simple-shoot-get-score.php");

    std::ostringstream oss;
    oss << "pseudo=" << m_parent->m_input_pseudo->GetLabelText()
        << "&"
        << "score="  << m_parent->m_score;

    requete.SetBody(oss.str());

    sf::Http::Response page = serveur.SendRequest(requete);

    if ( page.GetStatus() != sf::Http::Response::Ok ) {
        m_parent->m_str_inputLabel.SetText("Erreur de connexion");
    } else {
        m_parent->m_str_best_score.SetText(page.GetBody());
    }
}
