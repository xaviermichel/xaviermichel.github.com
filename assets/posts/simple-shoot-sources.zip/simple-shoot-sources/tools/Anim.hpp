//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef ANIM_H
#define ANIM_H

#include "constantes.hpp"

#include "PausableClock.hpp"


/*!
*	\class Anim
*	\brief Implémente la gestion des animation selon le temps.
*   \see http://www.sfml-dev.org/wiki/fr/sources
*/
class Anim
{
public:
        Anim(void);
        virtual ~Anim(void);

        //! Change au prochain frame d'animation
        void nextFrame();

        //! Change au frame d'animation défini par 'count'
        virtual void setFrame(const unsigned int &count);

        //! Définis la ligne animé courante
        virtual void setAnimRow(const unsigned int &row);

        //! Définis le nombre de lignes d'une animation
        virtual void setNbLine(const unsigned int &line);

        //! Retourne le nombre de lignes par animation
        int nbLine() const;

        //! Retourne la ligne animé courante
        int animRow() const;

        //! Change au premier frame animation
        void reset();

        //! Retourne le frame d'animation courante
        unsigned int currentFrame() const;

        //! Retourne la ligne d'animation courante
        unsigned int currentLine() const;

        //! Définis si l'animation est en boucle (choice=true)
        void loop(const bool &choice);

        //! Retourne si l'animation est joué en boucle
        bool isLoop() const;

        //! Joue l'animation
        void play();

        //! Arrête l'animation et remet le compteur à zéro
        void stop();

        //! Met l'animation en pause et laisse le compteur où il en est.
        void pause();

        //! Retourne true si l'animation joue
        bool isPlaying() const;

        //! Définis le délais en seconde entre chaque frame.
        void setDelay(const float &delay);

        //! Retourne le délai entre chaque frame
        float delay() const;

        //! Met à jour l'animation
        virtual void update();

        //! Retourne le nombre de frame de l'animation
        virtual unsigned int getSize() const=0;

        //! Définie si l'objet est un éphémère
        void setEphemere(const bool e);

        //! Est-ce un éphémère ?
        bool isEphmere() const;

protected:
        //! Timer de l'animation
        PausableClock m_time;

        //! Frame courant de l'animation
        unsigned int m_frameCount;

        //! Ligne courante de l'animation
        unsigned int m_lineCount;

        //! Délai en seconde entre chaque animation
        float m_delay;

        //! Si l'animation est en boucle
        bool m_isLoop;

        //! Si l'animation est en train de jouer
        bool m_play;

        //! Nombre de lignes d'une animation
        unsigned int nb_line;

        //! Ligne de début de l'animation courante
        unsigned int refLine;

        //! Si un objet est éphémère, il va jouer une fois son animation puis disparaitre
        bool m_ephemere;
};


#endif


