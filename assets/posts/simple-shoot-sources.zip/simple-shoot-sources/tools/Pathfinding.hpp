//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef PATHFINDING_TPP
#define PATHFINDING_TPP

#include "constantes.hpp"

#include "Monde.hpp"
#include "ImageManager.hpp"


/*!
    \struct Noeud
    \brief Un point dans la recherche du chemin
*/
struct Noeud {
    int g;         //!< Chemin parcouru pour en arriver là
    int h;         //!< distance restante jusqu'à l'arrivée
    int f;         //!< Somme de g et h, pour ne pas la recalculer à chaque fois
    Point parent;   //!< Le noeud précédent qui nous à permis d'arriver là
};


//! Nos listes de noeuds (liste ouverte et liste fermée)
typedef std::map<Point, Noeud> Noeuds;


//! \return La distance de Manhattan entre p1 et p2
inline int distanceManhattan(const Point &p1, const Point &p2) {
    return (p1.first-p2.first)*(p1.first-p2.first) + (p1.second-p2.second)*(p1.second-p2.second);
}

//! \return La distance Euclidienne entre p1 et p2
inline int distanceEuclidienne(const Point &p1, const Point &p2){
    return (int)sqrt(distanceManhattan(p1, p2));
}

/*!
    \class PathFinding
    \brief La classe qui va s'occuper de la recherche de chemin
*/
class PathFinding {

public :

        /*!
          Constructeur
          \param f Fonction à utiliser pour calculer l'euristique
          \param depart Point de départ
          \param arrivee Point d'arrivée
          \param monde Le monde dans lequel a lieu la recherche de chemin
          \param p Le pauvre petit pion qui cherche son chemin
        */
        PathFinding(int(*f)(const Point&, const Point&), const sf::Vector2f &depart, const sf::Vector2f &arrivee, Monde *monde, Pion *p) : m_f(f), m_monde(monde), m_p(p) {
            m_pDepart.first = depart.x;
            m_pDepart.second = depart.y;
            m_pArrivee.first = arrivee.x;
            m_pArrivee.second = arrivee.y;
        }



        /*!
            \brief La recherche du chemin, le A* en lui même donc
            \return La liste des points qui constituent le passage à emprunter
        */
        std::list<Point> lancer() {
            //clock_t start = clock();

            Noeuds openList;
            Noeuds closedList;

            Noeud currentNode;
            Point currentPoint;

            // on met le noeud de départ dans la liste ouverte
            currentNode.g = 0;
            currentNode.h = (*m_f)(m_pDepart, m_pArrivee);
            currentNode.f = currentNode.h;

            openList[m_pDepart] = currentNode;


            while (
                    ! arrive(currentPoint) // on n'est pas à l'arrivée
                    && ! openList.empty() // et il reste des noeuds a explorer
                    ) {


                // on récupère le meilleur noeud, forcément le premier comme on tri avec le foncteur
                currentPoint = meilleurNoeud(openList);
                currentNode = openList[currentPoint];

                // on l'enlève de la liste courante et on le passe dans la liste fermée
                closedList[currentPoint] = currentNode;
                openList.erase(currentPoint);

                // maintenant on traite les cases voisines

                for (int i=currentPoint.first - m_p->getVitesse(); i <= currentPoint.first + m_p->getVitesse(); i+=m_p->getVitesse()) {

                    if ( i<0 || i>= ImageManager::getImage("collision")->GetWidth() ) { // ne pas sortir de l'image
                        continue;
                    }


                    for (int j=currentPoint.second - m_p->getVitesse(); j <= currentPoint.second + m_p->getVitesse(); j+=m_p->getVitesse()) {

                        if ( j < 0 || j>= ImageManager::getImage("collision")->GetHeight() ) { // ne pas sortir de l'image non plus
                            continue;
                        }

                        if ( i == currentPoint.first && j == currentPoint.second ) {
                            // inutile de traiter cette case, c'est la case courante !
                            continue;
                        }

                        /*
                        // on ignore également les noeuds en diagonale
                        if (    i < currentPoint.first && j < currentPoint.second
                             || i > currentPoint.first && j > currentPoint.second
                             || i > currentPoint.first && j < currentPoint.second
                             || i < currentPoint.first && j > currentPoint.second
                             ) {
                            continue;
                        }
                        */

                        if ( ImageManager::getImage("collision")->GetPixel(i, j) != couleurLibre ) {
                            continue;
                        }


                        Point nouveauPoint;
                        nouveauPoint.first = i;
                        nouveauPoint.second = j;


                        if ( contient(closedList, nouveauPoint)) {
                            continue;
                        }

                        // on créé le nouveau noeud
                        Noeud nouveauNoeud;
                        nouveauNoeud.parent = currentPoint;

                        // on peut simuler le point qu'il en coute de se déplacer
                        // sur une case, là je choisi que toutes les cases coûtent 100
                        nouveauNoeud.g = currentNode.g + 100;
                        nouveauNoeud.h = (*m_f)(nouveauPoint, m_pArrivee);
                        nouveauNoeud.f = nouveauNoeud.g + nouveauNoeud.h;

                        if ( ! contient(openList, nouveauPoint) ) {
                            // pas encore dans la liste ouverte, donc on l'ajoute
                            openList[nouveauPoint] = nouveauNoeud;
                        } else {
                            // déjà dans la liste ouverte, avons nous trouvé un meilleur chemin ?
                            if ( nouveauNoeud.f < currentNode.f ) {
                                openList[nouveauPoint] = nouveauNoeud;
                            }
                        }
                    }
                }
            }

            //std::cout << "Temps d'execution fonction : " << (double)(clock()-start)/(double)CLOCKS_PER_SEC << " secondes" << std::endl;

            std::list<Point> chemin;

            // tracé du chemin
            if ( ! arrive(currentPoint) ) {
                std::cout << "pas de chemin trouvé :(" << std::endl << std::flush;
            }
            else {

                // il faut remonter tout le chemin pour le tracer :s
                while ( currentNode.parent != m_pDepart ) {
                    currentPoint = Point(currentNode.parent);
                    chemin.push_back(currentPoint);
                    currentNode = closedList[currentPoint];
                }
                chemin.reverse();
            }

            return chemin;
        }



protected :


        //! \return Vrai si la liste de noeud n contient le point p
        inline bool contient(Noeuds &n, Point p) const {
            return ( n.find(p) != n.end() );
        }


        //! \return Le meilleur noeud de la liste de noeuds passés en paramètres
        inline Point meilleurNoeud(Noeuds& n) const {

            Point p = n.begin()->first;
            float plusBasCout = n.begin()->second.f;

            for (Noeuds::iterator it = ++n.begin(); it != n.end(); ++it) {
                if ( it->second.f < plusBasCout ){
                    p = it->first;
                    plusBasCout = it->second.f;
                }
            }

            return p;
        }


        /*!
            \brief En fonction du delta, on n'arrivera pas forcément juste sur le point cliqué, cette fonction va donc voir si malgré le delta, on a atteint l'arrivée
            \return Vrai si on a atteint l'arrivée
        */
        inline bool arrive(Point p) const {
            return std::abs(p.first - m_pArrivee.first) <= m_p->getVitesse() && abs(p.second - m_pArrivee.second) <= m_p->getVitesse();
        }


        Pion *m_p;                               //!< Le pion qui cherche son chemin
        Monde *m_monde;                          //!< Monde dans lequel le jeu se déroule
        Point m_pDepart;                         //!< point de départ
        Point m_pArrivee;                        //!< point d'arrivée
        int (*m_f)(const Point&, const Point&);   //!< fonction à utiliser pour l'euristique

};



#endif // PATHFINDING_TPP


