//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ImgAnim.hpp"


ImgAnim::ImgAnim(const sf::Image &Img, const unsigned int &nbFrame, const unsigned int &line,
                        const sf::Vector2f &Position, const sf::Vector2f &Scale,float Rotation, const sf::Color &Col)
: sf::Sprite(Img,Position,Scale,Rotation,Col)
{
        m_animRow=0;
        //Le constructeur par défaut prend en compte qu'il n'y a aucun offset
        SetSubRect(sf::IntRect(0,0,Img.GetWidth()/nbFrame,Img.GetHeight()/line));
        m_xOffset=0;
        m_yOffset=0;
        m_size=nbFrame;
}

void ImgAnim::setFrameDim(const unsigned int &w, const unsigned int &h)
{
        sf::IntRect tRect = GetSubRect();
        SetSubRect(sf::IntRect(tRect.Left,tRect.Top,tRect.Left+w,tRect.Top+h));
}

sf::IntRect ImgAnim::frameDim() const
{
        sf::IntRect tRect = GetSubRect();
        return sf::IntRect(0,0,tRect.GetWidth(),tRect.GetHeight());
}

void ImgAnim::setOffset(const unsigned int &x, const unsigned int &y)
{
        m_xOffset=x;
        m_yOffset=y;

        refreshSubRect();
}

sf::IntRect ImgAnim::offset() const
{
        return sf::IntRect(0,0,m_xOffset,m_yOffset);
}

int unsigned ImgAnim::getSize() const
{
        return m_size;
}

void ImgAnim::setSize(const unsigned int &size)
{
        m_size=size;
}


void ImgAnim::setFrame(const unsigned int &count)
{
        Anim::setFrame(count);
        refreshSubRect();
}

void ImgAnim::refreshSubRect()
{
        sf::IntRect tRect = GetSubRect();
        SetSubRect(sf::IntRect(tRect.GetWidth()*currentFrame()+m_xOffset,
                                                        tRect.GetHeight()*currentLine()+m_yOffset,
                                                        tRect.GetWidth()*(currentFrame()+1)+m_xOffset,
                                                        tRect.GetHeight()*currentLine()+tRect.GetHeight()+m_yOffset));
}


void ImgAnim::Render(sf::RenderTarget& Target) const
{
        ImgAnim* th = const_cast<ImgAnim*>(this);
        th->update();
        sf::Sprite::Render(Target);
}

void ImgAnim::setPosition(float i, float j) {
        SetPosition(i, j);
}

int ImgAnim::getHeight() {
    sf::IntRect tRect = GetSubRect();
    return tRect.GetHeight();
}

int ImgAnim::getWidth() {
    sf::IntRect tRect = GetSubRect();
    return tRect.GetWidth();
}
