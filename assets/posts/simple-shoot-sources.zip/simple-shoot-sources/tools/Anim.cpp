//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Anim.hpp"


Anim::Anim(void) : m_time()
{
        m_frameCount=0;
        m_lineCount = 0;
        refLine = m_lineCount;
        nb_line = 1;
        m_delay=.08f;
        m_isLoop=true;
        m_play=true;
        m_ephemere = false;
}

Anim::~Anim(void)
{
}

void Anim::nextFrame()
{
        if(currentFrame()==getSize()-1)
        {
                        setFrame(0);
                        if(!isLoop())
                                stop();
        }
        else
                setFrame(currentFrame()+1);
}

void Anim::setFrame(const unsigned int &count)
{
        if(count<getSize())
                m_frameCount=count;
        else
        {
                m_frameCount=0;
        }
}

void Anim::setAnimRow(const unsigned int &row)
{
        m_lineCount = row * nb_line;
        refLine = m_lineCount;
        //refreshSubRect();
}

void Anim::setNbLine(const unsigned int &line)
{
    nb_line = line;
}

int Anim::nbLine() const
{
    return nb_line;
}

int Anim::animRow() const
{
        return m_lineCount;
}

void Anim::reset()
{
        stop();
        play();
}

void Anim::loop(const bool &choice)
{
        m_isLoop=choice;
}

void Anim::play()
{
        m_play = true;
        m_time.Play();
}

void Anim::stop()
{
        Anim::m_play = false;
        setFrame(0);
        m_time.Stop();
}

void Anim::pause()
{
        Anim::m_play = false;
        m_time.Pause();
}

bool Anim::isPlaying() const
{
        return m_play;
}

void Anim::setDelay(const float &delay)
{
        m_delay=delay;
}

float Anim::delay() const
{
        return m_delay;
}

unsigned int Anim::currentFrame() const
{
        return m_frameCount;
}

unsigned int Anim::currentLine() const
{
    return m_lineCount;
}

bool Anim::isLoop() const
{
        return m_isLoop;
}

void Anim::update()
{
        if(isPlaying())
        {
            if ( ! m_ephemere ) {
                if(delay())
                {
                    unsigned int frameCount = (unsigned int)(m_time.GetElapsedTime()/delay());
                    if(!isLoop() && frameCount>getSize())
                            stop();
                    else
                    {
                            unsigned int lineCount = ((int)frameCount/getSize()) % nb_line;
                            m_lineCount = lineCount + refLine;
                            frameCount = frameCount % getSize();
                            setFrame(frameCount);
                    }
                }
                else
                {
                    nextFrame();
                }
            }
            else // c'est un ephemere
            {
                unsigned int frameCount = (unsigned int)(m_time.GetElapsedTime()/delay());
                unsigned int lineCount = ((int)frameCount/getSize()) % nb_line;
                m_lineCount = lineCount + refLine;
                frameCount = frameCount % getSize();

                if ( m_frameCount == getSize() - 1 ) { // on arrive en bout de ligne
                    setAnimRow(currentLine()+1);
                    frameCount = 0;
                }
                setFrame(frameCount);

            }
        }
}

void Anim::setEphemere(const bool e) {
    m_ephemere = e;
}

bool Anim::isEphmere() const {
    return m_ephemere;
}
