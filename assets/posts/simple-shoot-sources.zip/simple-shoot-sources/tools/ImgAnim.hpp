//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef IMGANIM_H
#define IMGANIM_H

#include "constantes.hpp"

#include "Anim.hpp"

/*!
*	\class ImgAnim
*	\brief Comme Anim à la différence près que la classe utilise une image avec tout les sprites au lieu des couches d'une layer.
*   \see http://www.sfml-dev.org/wiki/fr/sources
*/
class ImgAnim :
        public Anim, public sf::Sprite
{
public:
        /*!
        *	\param Img Image avec les sprites
        *	\param nbFrame Nombre de frame par animation
        *	\param line Nombre de ligne d'animation
        *	\param [...] Voir la documentation de sf::Sprite
        */
        ImgAnim(const sf::Image &Img,
                const unsigned int &nbFrame,
                const unsigned int &line=1,
                const sf::Vector2<float> &Position=sf::Vector2f(0, 0),
                const sf::Vector2<float> &Scale=sf::Vector2f(1, 1),
                float Rotation=0.f,
                const sf::Color &Col=sf::Color(255, 255, 255, 255)
                );


        //! Définis les dimension d'un frame
        void setFrameDim(const unsigned int &w, const unsigned int &h);

        //! Retourne la dimension d'un frame
        sf::IntRect frameDim() const;

        //! Définis le décalage de l'animation sur l'image (permet d'avoir plusieurs anim sur une seule image)
        void setOffset(const unsigned int &x, const unsigned int &y);

        //! Retourne un rectangle avec l'offset
        sf::IntRect offset() const;

        //! Définis le frame courant
        virtual void setFrame(const unsigned int &count);

        //! Met à jour le rectangle d'animation
        void refreshSubRect();

        //! Définis le nombre de frame dans l'animation
        void setSize(const unsigned int &size);

        //! Retourne le nombre de frame
        virtual unsigned int getSize() const;

        //! Définis la position de l'élément sur l'écran
        void setPosition(float i, float j);

        //! Largeur de l'image
        int getWidth();

        //! Hauteur de l'image
        int getHeight();

protected:

        virtual void Render(sf::RenderTarget& Target) const;

private:
        //! Représente le nombre de frame dans l'animation
        unsigned int m_size;

        //! Ligne d'animation courante
        unsigned int m_animRow;

        //! Décalage à gauche du frameset
        unsigned int m_xOffset;

        //! Décalage en haut du frameset
        unsigned int m_yOffset;
};


#endif


