//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef PAUSABLECLOCK_H
#define PAUSABLECLOCK_H

#include "constantes.hpp"

/*!
    \class PausableClock
    \brief Une horloge avec quelques options supplémentaires
    \see http://www.sfml-dev.org/wiki/fr/sources
*/

class PausableClock : public sf::Clock
{
public:

        //! Initialise le timer et le start
        PausableClock();

        //! Met en pause le timer
        void Pause();

        //! Met en marche le timer
        void Play();

        //! Change l'état du timer (pause<->marche)
        bool Toggle();

        //! Arrete le timer et le remet à zéro
        void Stop();

        //! Remet le timer à zéro et le met en marche
        void Reset();

        //! Retourne le temps écouler depuis la dernière fois qu'il à été mis en marche (avec Reset ou Play).
        float GetElapsedTime();

private:

        float m_elapsedTime;    //!< Temps écoulé

        bool m_pause;           //!< Horloge en pause ?
};


#endif

