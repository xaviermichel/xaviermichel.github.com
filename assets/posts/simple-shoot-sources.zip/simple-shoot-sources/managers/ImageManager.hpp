//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef IMAGE_MANAGER_HPP
#define IMAGE_MANAGER_HPP

#include "Singleton.hpp"

class ImgAnim;

/*!
    \struct ImageData
    \brief Les données qui sont attachées à une image
*/
struct ImageData {
    bool isLoaded;      //!< La ressource est-elle chargée ?
    std::string url;    //!< URL de la ressource
    sf::Image *image;   //!< Image de la ressource
    int rowCount;       //!< Nombre de lignes de l'image
    int columnCount;    //!< Nombre de la colonne de l'image
};

/*!
    \class ImageManager
    \brief Le gestionnaire d'image
    Charge la ressource seulement quand celle-ci est demandée.
*/

class ImageManager : public Singleton<ImageManager>
{

friend class Singleton<ImageManager>;

public :

        /*!
            \brief Demande une ressource
        */
        static const sf::Image* getImage(const std::string &r);

        /*!
            \brief Demande une ressource sous la forme d'une nouvelle imgAnim
        */
        static ImgAnim* getImgAnim(const std::string &r);

private :
        /*!
            \brief Si la ressource n'est pas encore chargée, elle est chargée à ce moment.
        */
        void loadImage(const std::string &r);

protected:

        ImageManager();

        ~ImageManager();

        std::map<std::string, ImageData *> m_ressources;    //!< Les ressources

};

#endif // CARTE_HPP
