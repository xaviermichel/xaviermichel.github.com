//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "ImageManager.hpp"

#include "tinyxml.h"

#include "ImgAnim.hpp"


ImageManager::ImageManager() {

    TiXmlDocument imageDoc(DATA"/images.xml");
    if( ! imageDoc.LoadFile() ){
        std::cerr << "erreur lors du chargement de images.xml" << std::endl;
        std::cerr << "error #" << imageDoc.ErrorId() << " : " << imageDoc.ErrorDesc() << std::endl;
        exit(0);
    }

    TiXmlHandle hdlS(&imageDoc);
    TiXmlElement *elem = hdlS.FirstChildElement().FirstChildElement().Element();

    // On charge et stock toutes les informations contenues dans le xml.
    while( elem ){

        ImageData *id = new ImageData;
        id->url = elem->Attribute("url");
        id->isLoaded = false;

        if ( elem->Attribute("rowCount") ) {
            id->rowCount = atoi(elem->Attribute("rowCount"));
        } else {
            id->rowCount = 1;
        }

        if ( elem->Attribute("columnCount") ) {
            id->columnCount = atoi(elem->Attribute("columnCount"));
        } else {
            id->columnCount = 1;
        }

        m_ressources[std::string(elem->Attribute("name"))] = id;

        elem = elem->NextSiblingElement();
    }

}


ImageManager::~ImageManager() {

    for (std::map<std::string, ImageData *>::iterator it = m_ressources.begin(); it != m_ressources.end(); ++it) {
        if ( it->second->isLoaded ) {
            delete it->second->image;
        }
        delete it->second;
    }
    m_ressources.clear();

}

void ImageManager::loadImage(const std::string &r) {

    ImageManager *im = ImageManager::getInstance();

    if ( ! im->m_ressources[r]->isLoaded ) { // ressource pas encore chargée
        ImageData *id = im->m_ressources[r];

        sf::Image *i = new sf::Image();
        if ( ! i->LoadFromFile(DATA_IMAGES + id->url) ) {
            std::cerr << "Erreur chargement ressources : " << id->url << std::endl;
        }
        i->SetSmooth(false);
        i->CreateMaskFromColor(sf::Color(255,0,255));

        id->isLoaded = true;
        id->image = i;
    }

}

const sf::Image* ImageManager::getImage(const std::string &r) {
    ImageManager *im = ImageManager::getInstance();
    im->loadImage(r);
    return im->m_ressources[r]->image;
}

ImgAnim* ImageManager::getImgAnim(const std::string &r) {
    ImageManager *im = ImageManager::getInstance();
    im->loadImage(r);
    ImageData *id = im->m_ressources[r];
    return new ImgAnim(*id->image, id->columnCount, id->rowCount);
}
