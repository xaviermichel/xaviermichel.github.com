//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "SoundManager.hpp"

#include "tinyxml.h"

#include "Parametres.hpp"


SoundManager::SoundManager() {

    TiXmlDocument soundDoc(DATA"/sounds.xml");
    if( ! soundDoc.LoadFile() ){
        std::cerr << "erreur lors du chargement de sounds.xml" << std::endl;
        std::cerr << "error #" << soundDoc.ErrorId() << " : " << soundDoc.ErrorDesc() << std::endl;
        exit(0);
    }

    TiXmlHandle hdlS(&soundDoc);
    TiXmlElement *elemS = hdlS.FirstChildElement().FirstChildElement().Element();

    // On charge et stock toutes les informations contenues dans le xml.
    while( elemS ){

        SoundData *sd = new SoundData;
        sd->url = elemS->Attribute("url");
        sd->isLoaded = false;

        m_ressources[std::string(elemS->Attribute("name"))] = sd;

        elemS = elemS->NextSiblingElement();
    }

}


SoundManager::~SoundManager() {

    for (std::map<std::string, SoundData *>::iterator it = m_ressources.begin(); it != m_ressources.end(); ++it) {
        if ( it->second->isLoaded ) {
            delete it->second->sound;
            delete it->second->buffer;
        }
        delete it->second;
    }
    m_ressources.clear();

}


void SoundManager::playSound(const std::string &r) {

    SoundManager *sm = SoundManager::getInstance();

    if ( ! sm->m_ressources[r]->isLoaded ) { // ressource pas encore chargée

        SoundData *sd = sm->m_ressources[r];

        sf::SoundBuffer *sb = new sf::SoundBuffer();
        if ( ! sb->LoadFromFile(DATA_SONS + sd->url)) {
            std::cerr << "Erreur chargement ressources : " << sd->url << std::endl;
        }

        sf::Sound *s = new sf::Sound();
        s->SetBuffer(*sb);

        sd->isLoaded = true;
        sd->buffer = sb;
        sd->sound = s;
    }

    // lire la ressource
    if ( ! Parametres::isMute() ) {
        sm->m_ressources[r]->sound->Play();
    }

}
