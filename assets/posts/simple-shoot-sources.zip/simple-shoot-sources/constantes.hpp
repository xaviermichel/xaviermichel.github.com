//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef CONSTANTES_HPP
#define CONSTANTES_HPP

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>

#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <sstream>
#include <algorithm>

#define DATA            "ressources/"
#define DATA_IMAGES     "ressources/images/"
#define DATA_SONS       "ressources/sons/"
#define DATA_POLICES    "ressources/polices/"


typedef unsigned int uint;
typedef unsigned char uchar;


typedef std::pair<int,int> Point;  //!< un point est défini par un x et un y, on préfère se servir de int pour une question de rapidité (plutôt que Vector2f)


//! une approximation de la valeur de PI
const float PI = std::acos(-1.0);

/*!
    \enum DIRECTION
    \brief Les différentes directions dans lesquelles on peut se déplacer
    Cela correspond aussi au numéro de ligne sur le tileset d'animation
*/
enum DIRECTION {
    HAUT    = 2,        //!< Vers le haut
    BAS     = 0,        //!< Vers le bas
    GAUCHE  = 3,        //!< Vers la gauche
    DROITE  = 1         //!< Vers la droite
};

const sf::Color couleurMur(0,0,0);              //!< Couleur des murs, impossible de se déplacer dans un mur et les murs arrêtent les balles
const sf::Color couleurLibre(255, 255, 255);    //!< Couleur des case libres (on peut se déplacer et tirer sur les cases libres)
const sf::Color couleurEau(0, 0, 255);          //!< Couleur des case eau, on ne peut pas se déplacer sur l'eau mais les projectiles peuvent passer dessus

const uchar tailleViseur = 30;                  //!< La taille du viseur qui sera affiché à l'écran

const float tempsChangementArme = 0.5f;         //!< Le temps qu'il faut pour changer d'arme, sert à ne pas traiter plusieurs fois le roulement de la molette

const std::string codeUpload = "secret";        //!< Le code qui permet d'uploader le score sur mon serveur (pour ne pas que la base soit pourrie)

#endif // CONSTANTES_HPP

