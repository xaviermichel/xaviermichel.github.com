//
// Simple Shoot
// Copyright (C) 2010-2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

/*!

    \mainpage Simple Shoot
    \authors Xavier MICHEL
    \authors Game design by Daniel Cook (Lostgarden.com)
    \authors Nombreuse images/animations reprisent du projet <a href="http://www.bigz.fr/bamboclash/" target="_blank">bamboclash</a> (auquel j'ai activement participé)
    \version 0.2
    \date 29/12/2010

    \section presentation_generale_sec Présentation générale du projet



        \subsection but_sub Quel est le but du jeu ?

            Simple shoot est un simple jeu de tir dans lequel vous incarnez un petit personnage qui va subir des assauts de la part de plus en plus d'ennemis,
            qui tireront de plus en plus vite.

            Sur une carte, les missiles peuvent passer sur l'eau mais vous ne pouvez pas la traverser.
            Les missiles explosent quand ils touchent un ennemi ou s'ils atteignent le bord de la carte, l'explosion ne provoque pas de dégats.

            Vous ne pouvez pas être tué par vos propres missiles, mais les missile d'une IA peuvent tuer une autre IA.

            J'estime la durée d'une partie à environ deux minutes, mais le jeu commence à devenir difficile au bout de 80 secondes.

            L'IA apparait aléatoirement dans l'un des quatre angles de la carte. Plus le jeu dur longtemps, plus l'IA apparaitra vite et plus elle sera puissante.


        \subsection screen_sub Quelques captures d'écran et une vidéo

            \htmlonly

                <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
                <script type="text/javascript" src="../script/jquery.colorbox-min.js"></script>

                <link rel="stylesheet" media="screen" type="text/css" title="" href="../templates/colorbox.css" />

                <script>
                     $(document).ready(function(){
                         $("a[rel='shoot']").colorbox({transition:"fade", width:"90%"});
                     });
                </script>

                <table class="tabSansTraitCentre">
                 <tr>
                     <td>
                         <a href="../simple-shoot/sc-1.png" rel="shoot" title="">
                         <img src="../simple-shoot/sc-1.png" alt="" width="250px"/>
                         </a>
                     </td><td>
                         <a href="../simple-shoot/sc-2.png" rel="shoot" title="">
                         <img src="../simple-shoot/sc-2.png" alt="" width="250px"/>
                         </a>
                     </td><td>
                         <a href="../simple-shoot/sc-3.png" rel="shoot" title="">
                         <img src="../simple-shoot/sc-3.png" alt="" width="250px"/>
                         </a>
                     </td>
                 </tr>
                </table>

                <br/>

                <div class="align-center">
                    <video width="800" height="600" controls="controls" src="../simple-shoot/sc-1.webm" type="video/webm">
                     Votre navigateur ne supporte pas la balise vidéo.
                    </video>
                    <br/>
                    Si vous n'arrivez pas à voir la vidéo, vous pouvez <a href="../simple-shoot/sc-1.webm">la télécharger</a>.
                </div>

            \endhtmlonly


        \subsection manuel_sub Comment jouer ?

            Ce jeu étant assez simple, les touches qui vous permettent de jouer le sont aussi.
                - <b>Z, Q, S, D</b> Vous serviront à vous déplacer dans le monde
                - <b>R</b> Redémarrer la partie
                - <b>Clique gauche souris</b> Pour tirer un projectile dans la direction dans laquelle vous avez cliqué
                - <b>Molette souris</b> Pour changer d'arme
                - <b>M</b> Permet de mettre le jeu en muet, ou de remettre le son


        \subsection dl_sub Téléchargement

            Si vous le souhaité, vous pouvez télécharger le jeu via les liens suivant :
                - <a href="../simple-shoot/simple-shoot-windows.zip">Télécharger Simple Shoot pour windows</a>
                - <a href="../simple-shoot/simple-shoot-linux.zip">Télécharger Simple Shoot pour linux</a> (vous devez avoir la SFML >= 1.6 pour exécuter)
                - Si vous êtes sous mac et que vous voulez tester, vous n'avez qu'à compiler les sources
                - <a href="../simple-shoot/simple-shoot-sources.zip">Télécharger les sources Simple Shoot</a>


    \section presentation_technique_sec Présentation technique du projet


        \subsection general_sub Généralités

            Ce jeu n'a pas pour vocation de devenir quelque chose de très complet, il s'agissait juste pour moi de réaliser un petit quelque chose pour m'occuper
            car c'est en codant que l'on apprend à coder !
            Je sais que se lancer dans un projet trop complet prend énormément de temps et d'investissement, pour des résultats qui n'avancent pas aussi vite que
            l'on le souhaiterais (je pense à bamboclash). Malgré beaucoup d'investissement on se rend compte que
            produire un jeu de qualité est vite un énorme casse-tête, c'est pour cela que j'ai préféré me focaliser sur quelque chose de très simple, mais qui
            devait être réalisé très proprement. J'ai d'ailleurs repris quelques morceaux de codes de bamboclash pour Simple Shoot.

            Ce jeu est sous licence <a href="http://en.wikipedia.org/wiki/Zlib_license" target="_blank">zlib</a>.


        \subsection outils_sub Liste des outils utilisés

            - Pour le choix du langage, je me suis tourné directement vers le c++, pour sa rapidité d'exécution (discutable pour un jeu 2d) mais pour la rigueur qu'il impose. En effet,
            je trouve que ce langage aide à prendre de bonnes habitudes via une syntaxe très stricte. J'ai mis un accent particulier sur le fait de produire un code propre. Un
            dernier point c'est que j'aime ce langage alors pourquoi m'en priver ?

            - <a href="http://www.sfml-dev.org" target="_blank">SFML</a>  : la fameuse bibliothèque permettant de gérer à la fois l'affichage, mais ouvrant la possibilité de gestion de son, réseau...
                J'ai déjà travaillé auparavant avec cette bibliothèque et j'ai été très satisfait de cette expérience. Prise en main très simple et instinctive, ce sont ces points
               qui m'ont poussé à utiliser une nouvelle fois cet outil.

            - <a href="http://www.stack.nl/~dimitri/doxygen" target="_blank">Doxygen</a> : souvent, on ne commente pas assez son code, on ne sait plus ce que fait telle ou telle fonction, qu'est-ce
                qu'elle attend en paramètre... Je me suis donc imposé d'écrire une documentation complète avec doxygen. J'ai également déjà utilisé cet outil de façon plus succincte,
                mais là je voulais voir plus loin, quels étaient les avantages apportés (diagramme UML, ...).


        \subsection obj_sub Objectifs technique de ce jeu

            Le but premier était d'avoir un code propre, souple et adaptable. Je pense avoir validé ces objectifs, en mettant en amont du codage une grosse réflexion sur
            l'architecture du projet. D'autre part l'expérience apportée par d'autres projets m'a permis de ne pas refaire les même erreurs.

            L'un des points clé de l'implémentation est l'IA. En effet elle constitue la tache qui m'a donnée le plus de fil à retordre. De la recherche de chemin à l'esquive
            de missile, le tout en trouvant en compromis entre efficacité (difficulté ?) et performance.


        \subsection compli_sub Comment compiler ?

            Pour ma part j'utilise QtCreator donc le .pro est dans l'<a href="../simple-shoot/simple-shoot-sources.zip">archive qui contient les sources</a>. Sinon, via un autre IDE, il faut linker la sfml :
            \verbatim
-lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -lsfml-network
            \endverbatim


        \subsection map_sub Notes sur les images

            Le coté graphique est clairement délaissé, ce n'était pas le but de l'exercice, et je ne suis pas designer. J'ai cependant fait un effort énorme
            pour que ça ne pique pas trop les yeux. Les images sont tirées de <a href="http://www.lostgarden.com/2009/03/dancs-miraculously-flexible-game.html" target="_blank">ce pack</a>.
            La licence me demande de citer son auteur (ce qui est déjà fait en haut de la page, mais un rappel ne fait pas mal) :

            <em>Game design by Daniel Cook (Lostgarden.com)</em>

            La couleur qui correspond à la partie à passer en transparence est (255, 0, 255) sur toutes les images (le gestionnaire de ressources images est
            très simple, ce qui est largement suffisant vu la taille du projet) ; Sinon il faudrait mettre en place le chargement via un xml... Ce que j'ai
            fait pour bamboclash, mais là ce n'était clairement pas un objectif.

            La carte est définie par un fond et une image de colision (voir map.psd), on peut l'éditer avec gimp pour la modifier.
            Le noir (0, 0, 0) correspond à un obstacle, le bleu (0, 0, 255) à l'eau. Les cases libres <em>doivent</em> être blanches.


       \subsection xml_sub Structures des fichiers xml

            \subsubsection xml_sound Le xml des sons

            Exemple de la stucture du fichier xml des sons :

            \verbatim
<?xml version='1.0' encoding='utf-8'?>
<sounds>
    <son name="explosion" url="explosion.wav" />            <!-- name est le nom du son, url le nom du fichier -->
    <son name="shuriken1" url="shuriken1.wav" />
    <son name="shuriken2" url="shuriken2.wav" />
</sounds>
           \endverbatim

           \subsubsection xml_image Le xml des images

           Exemple de la structure du fichier xml des images :
           \verbatim
<?xml version='1.0' encoding='utf-8'?>
<images>
    <image name="fond" url="carte.png" />                                           <!-- rowCount et columnCount sont automatiquement fixés à 1 -->
    <image name="collision" url="collisions.png" />                                 <!-- name est le nom de l'image, url le nom du fichier -->
    <image name="viseur" url="viseur.png" />
    <image name="roquette" url="missile.png" rowCount="1" columnCount="17" />       <!-- Là ils sont renseignés, on prend donc leurs valeurs (1, 17) bien que rowCount soit optionnel-->
    <image name="personnage" url="pion.png" rowCount="4" columnCount="8" />
    <image name="explosion" url="explosion.png" rowCount="5" columnCount="5" />
    <image name="shuriken" url="shuriken.png" rowCount="1" columnCount="8" />
    <image name="sang" url="blood.png" rowCount="1" columnCount="10" />
    <image name="fond_score_input" url="scoreInputArrierePlan.png" />
</images>
            \endverbatim


            \subsubsection xml_objects Le xml des objets

            Le fichier objets est un peu plus complet. Il est découpé en deux grandes parties :
            - weapons : les armes
            - ephemerals : les éphémères

            Il faut bien veiller à ne pas avoir de conflit dans les noms d'objet (arme et éphémères confondus).

            Dans la partie arme, on a la possibilité d'ajouter une condition pour déclencher un son ou un éphémère (ou encore un éphémère composé uniquement d'un son). Les conditions gérées sont :
            - hasKilledSomeone : le projectile a tué quelqu'un
            - notHasKilledSomeone : L'inverse de la condition ci dessus

            Attention à la récursivité si on décide de créer un autre éphémère à la création d'un éphémère.

            \verbatim
<?xml version='1.0' encoding='utf-8'?>
<objects>
    <weapons>
		<weapon name="rocket" speed="4.8" width="11.5" height="48.5" reload="1.0" ui="ui_lance_roquette" mouse="viseur_roquette">              <!-- Dans l'ordre : nom de l'arme, vitesse des projectiles, largeur des projectiles, hauteur des projectile, temps de rechargement, l'affichage de l'arme dans l'interface utilisateur (la liste des armes), le viseur (ou icône à mettre sur la souris lors de l'utilisation -->
            <images>
                <image triggered="onCreate" name="roquette" />                                  <!-- Si on avait plusieurs images onCreate, le programme en choisirait une aléatoirement -->
            </images>
            <sounds />                                                                          <!-- On peut bien évidemment décider de jouer un son à la construction -->
            <ephemerals>
                <ephemeral triggered="onDestroy" name="explosion" />                            <!-- L'éphémère à jouer à la destruction, il est défini ci-dessous -->
            </ephemerals>
        </weapon>
        <weapon name="shuriken" speed="2.8" width="20.0" height="20.0" reload="0.18" ui="ui_shuriken" mouse="viseur_shuriken">
            <images>
                <image triggered="onCreate" name="shuriken" />
            </images>
            <sounds>
                <sound triggered="onDestroy" name="shuriken1" />                                <!-- Lecture aléatoire d'un son à la destruction, sans aucune condition -->
                <sound triggered="onDestroy" name="shuriken2" />
            </sounds>
            <ephemerals>
                <ephemeral triggered="onDestroy" name="blood" condition="hasKilledSomeone" />   <!-- Exemple d'utilisation de condition (géré sur les éphémères et les sons uniquement) -->
            </ephemerals>
        </weapon>
    </weapons>
    <ephemerals>
        <ephemeral name="explosion" width="64.0" height="64.0">                                 <!-- Dans L'ordre : nom de l'éphémère, largeur , hauteur -->
            <images>
                <image triggered="onCreate" name="explosion" />                                 <!-- A la création, image et son d'explosion -->
            </images>
            <sounds>
                <sound triggered="onCreate" name="explosion" />
            </sounds>
            <ephemerals />
        </ephemeral>
        <ephemeral name="blood" width="65.0" height="43.0">
            <images>
                <image triggered="onCreate" name="sang" />
            </images>
            <sounds />
            <ephemerals />
        </ephemeral>
    </ephemerals>
</objects>
            \endverbatim

*/

