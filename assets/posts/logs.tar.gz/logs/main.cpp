/*
    Exemple d'utilisation de la classe Log
*/

#include <iostream>
#include <fstream>

#include <map>
#include <set>
#include <list>
#include <vector>
#include <deque>

#include "Log.hpp"

struct Foo {

    int bar;

    Foo() : bar(9) {
        Log::i("Foo") << "some Foo has been created, bar is : " << bar;
    }

    void doSomething() {
        Log::d("Foo") << "I'm doing something...";
    }

    void criticalFunction() {
        Log::d("Foo") << "Enter in critical part... Cross fingers";
        // do someting ...
        Log::w("Foo") << "It's going to crash";
        // some code ...
        Log::e("Foo") << "The sky is blue";       // mettre un message pour savoir pourquoi l'appli génère une erreur (erreur de type dans une fabrique par exemple)
    }

    friend std::ostream& operator <<(std::ostream&, const Foo&);
};

std::ostream& operator <<(std::ostream& stream, const Foo& foo) {
    stream << "Je suis Foo =) -> " << foo.bar;
    return stream;
}






int main(void) {

    // au démarage, TOUS les logs sont écris sur la sortie standard
    Log::v("main") << "Welcome in my testing prog";


    // on veut écrire les messages dans un fichier
    std::ofstream file("logs.txt");  // c'est à vous de traiter l'erreur d'ouverture du fichier !
    Log::setOutput(file);


    // message sans tag : fonctionne mais à éviter le plus possible (on ne sait pas vraiment d'où vient le message)
    Log::v() << "Voici un message sans tag";


    // on ne veut afficher que les messages qui sont au dessus du niveau DEBUG (donc ignorer les VERBOSES)
    Log::setLogLevel(DEBUG);


    Foo f;
    f.doSomething();
    f.criticalFunction();

    Log::d("main") << f;    // on peut bien entendu balancer des objets coutables


    bool b = true;
    Log::i("main") << "Demain il fera beau : " << b;    // voir spécialisation template bool


    // On peut basculer sur la sortie standard (ou n'importe quel ostream) quand on veut
    Log::setOutput(std::cout);
    Log::i("main") << "critical function -> ok";


    // une pair
    std::pair<int, std::string> somePair(42, "THE answer !");
    Log::d() << somePair;

    // une map
    std::map<int, std::string> someMap;
    someMap[18] = "my favorite number, so perfect...";
    someMap[42] = "the answer";
    Log::d() << someMap;

    // un set
    std::set<int> someSet;
    someSet.insert(42);
    someSet.insert(18);
    Log::d() << someSet;

    // une liste... de pair !
    std::list< std::pair<int, std::string> > someList;
    someList.push_back(somePair);
    someList.push_back( std::pair<int, std::string>(18, "my favorite number, so perfect...") );
    Log::d() << someList;

    // un vecteur
    std::vector<std::string> someVector;
    someVector.push_back("my favorite number, so perfect...");
    someVector.push_back("THE answer !");
    Log::d() << someVector;

    // un deque
    std::deque<int> someDeque;
    someDeque.push_back(18);
    someDeque.push_back(42);
    Log::d() << someDeque;

    // une multimap
    std::multimap<int, char> someMultimap;
    someMultimap.insert(std::pair<int, char>(1, 'a'));
    someMultimap.insert(std::pair<int, char>(1, 'b'));
    someMultimap.insert(std::pair<int, char>(2, 'c'));
    someMultimap.insert(std::pair<int, char>(2, 'a'));
    Log::d() << someMultimap;

    // multiset
    std::multiset<int> someMultiset;
    someMultiset.insert(9);
    someMultiset.insert(42);
    someMultiset.insert(18);
    someMultiset.insert(42);
    Log::d() << someMultiset;


    Log::v("main") << "Hope I'll see you later, bye !";       // ce verbose sera donc ignoré (on ne s'intéresse qu'au dessus de DEBUG)

    return 0;
}
