/*
	Syst�me de callback via type erasure
*/

#include <iostream>
 
class Widget {
};
 
 
class Callback {
	public :
		virtual ~Callback() {
		}
		virtual void triggerCallback(Widget*) {
		}
};
 
 
template<class T>
class CallbackT : public Callback {
	public :
		CallbackT( void(T::*f)() ): f(f) {
		}
		void triggerCallback(T *w) {
			(static_cast<T*>(w)->*f)();
		}	
 
	protected :
		void (T::*f)();
};
 
 
class MonBouton : public Widget {
 
	public :
		MonBouton(Widget *papa) : papa(papa) {
		}
 
		template<class CLASS>
		void setCallback( void(CLASS::*f)() ) {
			myCallback = new CallbackT<CLASS>(f);
		}
 
		void triggerCallback() { // se d�clenche sur un clique par exemple 
			myCallback->triggerCallback(papa);	
		}
 
	protected :
		Widget *papa;
		Callback *myCallback;
 
};
 
 
class MaFenetre : public Widget { // h�rite de �cran par exemple
 
	public :
		MaFenetre() {
			MonBouton *btn  = new MonBouton(this);
			btn->setCallback(&MaFenetre::btn_clicked);
 
			// simulation du clique
			btn->triggerCallback();
		}
 
		void btn_clicked() {
			std::cout << "bouton cliqu� !" << std::endl;
		}
};
 
 
int main(void) {
	MaFenetre f;
	return 0;
}

