//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "Tools.hpp"

Tools::Tools Tools::m_shared_tools;

Tools::Tools()  {

    // les couleurs des niveaux de log
    m_mapColor[VERBOSE] = QColor(210, 210, 210);
    m_mapColor[DEBUG]   = QColor(255, 255, 255);
    m_mapColor[INFO]    = QColor(255, 255, 255);
    m_mapColor[WARNING] = QColor(230, 230, 30);
    m_mapColor[ERROR]   = QColor(210, 30, 30);

    // les couleurs du texte des niveaux de log
    m_mapTextColor[VERBOSE] = QColor(0, 0, 0);
    m_mapTextColor[DEBUG]   = QColor(40, 40, 230);
    m_mapTextColor[INFO]    = QColor(0, 120, 0);
    m_mapTextColor[WARNING] = QColor(0, 0, 0);
    m_mapTextColor[ERROR]   = QColor(0, 0, 0);


    /*
    // les couleurs version couleur du papier peint chez une mamie
    m_mapColor[VERBOSE] = QColor(210, 210, 210);
    m_mapColor[DEBUG]   = QColor(92, 139, 206);
    m_mapColor[INFO]    = QColor(155, 177, 67);
    m_mapColor[WARNING] = QColor(209, 138, 92);
    m_mapColor[ERROR]   = QColor(190, 87, 87);

    m_mapTextColor[VERBOSE] = QColor(0, 0, 0);
    m_mapTextColor[DEBUG]   = QColor(0, 0, 0);
    m_mapTextColor[INFO]    = QColor(0, 0, 0);
    m_mapTextColor[WARNING] = QColor(0, 0, 0);
    m_mapTextColor[ERROR]   = QColor(0, 0, 0);
    */


    // table des correspondances entre texte et niveau de log
    m_mapDico["v"] = VERBOSE;
    m_mapDico["d"] = DEBUG;
    m_mapDico["i"] = INFO;
    m_mapDico["w"] = WARNING;
    m_mapDico["e"] = ERROR;

    // et enfin, la map avec les niveaux et leur texte associé (dans la combo)
    m_mapDisplayedText[VERBOSE] = "verbose                  ";
    m_mapDisplayedText[DEBUG]   = "debug                    ";
    m_mapDisplayedText[INFO]    = "information           ";
    m_mapDisplayedText[WARNING] = "warning                 ";
    m_mapDisplayedText[ERROR]   = "error                       ";

}


const QColor & Tools::getColor(LogLevel level) {
    return m_shared_tools.m_mapColor[level];
}

const QColor & Tools::getTextColor(LogLevel level) {
    return m_shared_tools.m_mapTextColor[level];
}

LogLevel Tools::getLevel(const QString &level) {
    return m_shared_tools.m_mapDico[level];
}

LogLevel Tools::getLevelFromColor(const QColor &color) {
    return m_shared_tools.m_mapColor.key(color);
}

const QColor & Tools::getColorFromText(const QString &levelText) {
    return m_shared_tools.m_mapColor[m_shared_tools.m_mapDisplayedText.key(levelText)];
}

const QColor & Tools::getTextColorFromText(const QString &levelText) {
    return m_shared_tools.m_mapTextColor[m_shared_tools.m_mapDisplayedText.key(levelText)];
}

QString Tools::getTextFromLevel(LogLevel level) {
    return m_shared_tools.m_mapDisplayedText[level];
}
