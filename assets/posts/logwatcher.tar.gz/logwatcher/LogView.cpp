//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "LogView.hpp"

#include "LogModel.hpp"

LogView::LogView() : m_combo(0) {

    verticalHeader()->hide();

    // interdire l'édition
    setEditTriggers(QAbstractItemView::NoEditTriggers);

    // et pas de sélection non plus
    setSelectionMode(QAbstractItemView::NoSelection);
}


void LogView::resize(int parentWidth) {
    setColumnWidth(0, 0.1 * parentWidth);
    setColumnWidth(1, 0.85 * parentWidth);
}


void LogView::hideLogLevel(LogLevel l, bool hide) {

    for (int i = 0; i < model()->rowCount(); ++i) {
        if ( l == Tools::getLevelFromColor(qobject_cast<LogModel*>(model())->item(i, 0)->background().color() ) ) {
            setRowHidden(i, hide);
        }
    }
}

void LogView::lineAdded() {

    // masquer la ligne si nécessaire
    LogModel *m = qobject_cast<LogModel*>(model());
    if ( ! m_combo->isChecked(Tools::getLevelFromColor(m->item(m->rowCount() - 1, 0)->background().color()) )) {
        setRowHidden(m->rowCount() - 1, true);
    }

    // fixer la hauteur des lignes
    setRowHeight(m->rowCount() - 1, 20);

    // aller en bas
    scrollToBottom();
}


void LogView::setCombo(ComboLogLevel *combo) {

    // effacer anciennes infos
    qobject_cast<LogModel*>(model())->clear();
    if ( m_combo ) {
        disconnect(m_combo, SIGNAL(updated()));
    }

    // mémoriser nouvelles infos
    m_combo = combo;
    connect(m_combo, SIGNAL(updated()), this, SLOT(logsLevelUpdated()));
}


void LogView::logsLevelUpdated() {
    for (int i = 0; i < NB_LOG_LEVEL; ++i) {
        hideLogLevel(static_cast<LogLevel>(i), ! m_combo->isChecked(static_cast<LogLevel>(i)));
    }
}
