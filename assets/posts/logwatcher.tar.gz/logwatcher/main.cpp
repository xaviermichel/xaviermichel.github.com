//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include <QtGui/QApplication>
#include <QTextCodec>

#include "MainWindow.hpp"

/*
Exemple de fichier d'entrée :
-----------------------------

[v] main : Welcome in my testing prog                                                                                             (main.cpp:34)
[i] main : critical function -> ok                                                                                                (main.cpp:50)
[i] Foo : some Foo has been created                                                                                               (main.cpp:13)
[d] Foo : I'm doing something...                                                                                                  (main.cpp:17)
[d] Foo : Enter in critical part... Cross fingers                                                                                 (main.cpp:21)
[w] Foo : It's going to crash                                                                                                     (main.cpp:23)
[e] Foo : The sky is blue                                                                                                         (main.cpp:25)
[e] Foo : The sky is blue                                                                                                         (main.cpp:25)
*/


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));

    MainWindow w;
    w.show();

    return a.exec();
}
