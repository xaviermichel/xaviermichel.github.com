//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef TOOLS_HPP
#define TOOLS_HPP

#include <QColor>
#include <QMap>
#include <QString>

/*!
  \enum LogLevel
  \brief Les différents niveaux de log.
*/
enum LogLevel {
    VERBOSE,     //!< verbeux
    DEBUG,       //!< debug
    INFO,        //!< information
    WARNING,     //!< attention
    ERROR,       //!< erreur
    NB_LOG_LEVEL //!< nombre d'élements dans l'énumération
};

/*!
  \class Tools
  \brief Le nom est plutôt mal choisis... On devrait parler de "data". Il y a là toutes les données du programme.
  En modifiant uniquement cette classe on gère tous les niveaux de log que l'on veut !
*/

class Tools {

public :
    /*!
      \brief Quelle est la couleur associée à un niveau ?
    */
    static const QColor & getColor(LogLevel level);

    /*!
      \brief Quelle est la couleur associée à un texte à un niveau ?
    */
    static const QColor & getTextColor(LogLevel level);

    /*!
       \brief Quel est le niveau de cette couleur ?
    */
    static LogLevel getLevelFromColor(const QColor &color);

    /*!
      \brief Quel est le niveau de ce libellé ?
    */
    static LogLevel getLevel(const QString &level);

    /*!
      \brief Quelle est la couleur de ce libellé ?
    */
    static const QColor & getColorFromText(const QString &levelText);

    /*!
      \brief Quelle est la couleur de texte de ce libellé ?
    */
    static const QColor & getTextColorFromText(const QString &levelText);

    /*!
      \brief Quelle est le libellé de ce niveau ?
    */
    static QString getTextFromLevel(LogLevel level);

protected :
    /*!
      Constructeur privé car Singleton !
    */
    Tools();

    /*!
      L'instance du singleton
    */
    static Tools m_shared_tools;

private :
    QMap<LogLevel, QColor> m_mapColor;              //!< Niveau de log / couleur
    QMap<LogLevel, QColor> m_mapTextColor;              //!< Niveau de log / couleur texte
    QMap<QString, LogLevel> m_mapDico;              //!< Nom donné dans le fichier de log (souvent en une lettre) / Niveau de log
    QMap<LogLevel, QString> m_mapDisplayedText;     //!< Niveau de log / libellé

};

#endif // TOOLS_HPP
