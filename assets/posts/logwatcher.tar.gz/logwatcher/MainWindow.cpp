//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "MainWindow.hpp"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), m_fileSelector("Tous (*.*)", "", "Selectionnez le fichier de logs")
{

    resize(800, 350);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    QHBoxLayout *headLayout = new QHBoxLayout();

    QWidget *centralWidget = new QWidget();
    setCentralWidget(centralWidget);
    centralWidget->setLayout(mainLayout);

    QPushButton *btn_clearLog = new QPushButton("Vider");

    headLayout->addWidget(&m_fileSelector);
    headLayout->addWidget(&m_comboLogLevel);
    headLayout->addWidget(btn_clearLog);
    mainLayout->addLayout(headLayout);

    m_logView.setModel(&m_logModel);
    resizeEvent();
    mainLayout->addWidget(&m_logView);
    m_logView.setCombo(&m_comboLogLevel);

    connect(&m_fileSelector, SIGNAL(selectedFileChanged(QString)), &m_logModel, SLOT(setLogFile(QString)));
    connect(btn_clearLog, SIGNAL(clicked()), &m_logModel, SLOT(clear()));
    connect(&m_logModel, SIGNAL(lineAdded()), &m_logView, SLOT(lineAdded()));

    // Pour les test, pour ne pas avoir à recharger un fichier de log à chaque démarage =)
    //m_fileSelector.selectFile("/home/xavier/foo/saffir-xawaxx/logs-build-desktop/logs.txt");

    if( QCoreApplication::arguments().count() > 1 ) {
        m_fileSelector.selectFile(QCoreApplication::arguments().at(1));
    }
}



void MainWindow::resizeEvent(QResizeEvent *) {
    m_logView.resize(width());
}
