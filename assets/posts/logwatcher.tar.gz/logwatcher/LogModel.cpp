//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "LogModel.hpp"

LogModel::LogModel() {

    // en-tete des colonnes
    QStringList header;
    header << "Tag" << "Message";
    setHorizontalHeaderLabels(header);

    // on n'a aucune taille de fichier pour l'instant
    m_fileDefined = false;

    // lancement du raffraichissement du log
    m_timer = new QTimer(this);
    m_timer->setInterval(500);
    m_timer->start();
    connect(m_timer, SIGNAL(timeout()), SLOT(readNewLogs()));
}


void LogModel::setLogFile(const QString &path) {

    if ( ! QFile::exists(path )) {
        QMessageBox::critical(0, "Erreur", "Le fichier défini n'existe pas !");
        return;
    }

    clear();
    m_filePath = path;
    m_fileDefined = true;
    m_fileSize = 0;
    m_errorShowed = false;
    m_lastReadedLine = -1;
}


void LogModel::readNewLogs() {

    if ( ! m_fileDefined ) {
        return;
    }

    QFile f(m_filePath);
    if ( ! f.open(QIODevice::ReadOnly) && ! m_errorShowed ) {
        m_errorShowed = true;
        QMessageBox::critical(0, "Erreur", "Impossible d'ouvrir le fichier : " + f.errorString());
        return;
    }

    if ( f.size() < m_fileSize ) {  // le fichier vient d'être vidé
        clear();
        m_lastReadedLine = 0;
    } else if ( f.size() == m_fileSize ) { // pas de nouvelles modifications
        return;
    }
    m_fileSize = f.size();

    qint64 lineNumber = 0;

    QTextStream fileStream(&f);
    while ( ! fileStream.atEnd() ) {

        ++lineNumber;

        QString line = fileStream.readLine();

        if ( lineNumber <= m_lastReadedLine ) { // on a déjà affiché cette ligne
            continue;
        }

        QRegExp regexp("\\[(.*)\\]([^:]*):(.*)"); // \[(.*)\]([^:]*):(.*)
        int pos = regexp.indexIn(line);
        if ( pos > -1 ) {
            appendRow(new QStandardItem(regexp.cap(2).trimmed()));
            setItem(rowCount()-1, 1, new QStandardItem(regexp.cap(3).trimmed()));

            for (int i=0; i < columnCount(); ++i) {
                item(rowCount()-1, i)->setForeground(
                        QBrush(
                                Tools::getTextColor(Tools::getLevel(regexp.cap(1).trimmed()))
                        )
                );
                item(rowCount()-1, i)->setBackground(
                        QBrush(
                                Tools::getColor(Tools::getLevel(regexp.cap(1).trimmed()))
                        )
                 );
            }

            emit lineAdded();

        } else {
            qDebug() << "erreur regexp" << line;
        }
    }

    m_lastReadedLine = lineNumber;
}

void LogModel::clear() {
    removeRows(0, rowCount());
}
