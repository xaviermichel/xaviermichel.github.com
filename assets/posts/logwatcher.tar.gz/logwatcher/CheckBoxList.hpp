//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef CHECKBOXLIST_H
#define CHECKBOXLIST_H

#include <QWidget>
#include <QString>
#include <QPaintEngine>
#include <QComboBox>

/*!
  \class CheckBoxList
  \see http://da-crystal.net/2008/06/checkbox-in-qcombobox/
  \brief J'ai juste ajouté un signal lorsque l'édition est terminée.
*/

class CheckBoxList: public QComboBox
{
Q_OBJECT;

public:
        CheckBoxList(QWidget *widget = 0);
        virtual ~CheckBoxList();
        bool eventFilter(QObject *object, QEvent *event);
        virtual void paintEvent(QPaintEvent *);
        void SetDisplayText(QString text);
        QString GetDisplayText() const;

signals :
        /*!
          \brief Fin des modifications
        */
        void updated();

protected slots :
        /*!
          \brief C'est ce slot qui émait le signal updated()
        */
        void emitUpdate();

private:
        QString m_DisplayText;
};

#endif // CHECKBOXLIST_H
