//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef MAINWINDOW_HPP
#define MAINWINDOW_HPP

#include <QMainWindow>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QCheckBox>
#include <QCoreApplication>

#include "Tools.hpp"

#include "LogModel.hpp"
#include "LogView.hpp"
#include "FileSelector.hpp"
#include "ComboLogLevel.hpp"

/*!
  \class MainWindow
  \brief La fenêtre principale du programme
*/

class MainWindow : public QMainWindow {

Q_OBJECT

public :
    MainWindow(QWidget *parent = 0);

protected :
    /*!
      \brief Pour appeller le redimmensionnement des enfants
    */
    void resizeEvent(QResizeEvent * = 0);

private :
    LogView  m_logView;            //!< La vue des logs (la table)
    LogModel m_logModel;           //!< Le modèle des logs (qui contient les données)
    FileSelector m_fileSelector;   //!< Permet de sélectionner le fichier qui contient les logs
    ComboLogLevel m_comboLogLevel; //!< La combo qui défini le niveau de log à afficher

};

#endif // MAINWINDOW_HPP
