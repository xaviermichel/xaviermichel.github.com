//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include "CheckBoxList.hpp"
#include "CheckBoxListDelegate.hpp"

#include <QtGui>


CheckBoxList::CheckBoxList(QWidget *widget )
:QComboBox(widget),m_DisplayText("")
{
        // set delegate items view
        CheckBoxListDelegate *c = new CheckBoxListDelegate(this);
        connect(c, SIGNAL(updated()), this, SLOT(emitUpdate()));
        view()->setItemDelegate(c);

        // Enable editing on items view
        view()->setEditTriggers(QAbstractItemView::CurrentChanged);

        // set "CheckBoxList::eventFilter" as event filter for items view
        view()->viewport()->installEventFilter(this);

        // it just cool to have it as defualt ;)
        //view()->setAlternatingRowColors(true);
}


void CheckBoxList::emitUpdate() {
    emit updated();
}


CheckBoxList::~CheckBoxList()
{
        ;
}


bool CheckBoxList::eventFilter(QObject *object, QEvent *event)
{
        // don't close items view after we release the mouse button
        // by simple eating MouseButtonRelease in viewport of items view
        if(event->type() == QEvent::MouseButtonRelease && object==view()->viewport())
        {
                return true;
        }
        return QComboBox::eventFilter(object,event);
}


void CheckBoxList::paintEvent(QPaintEvent *)
{
    QStylePainter painter(this);
    painter.setPen(palette().color(QPalette::Text));

    // draw the combobox frame, focusrect and selected etc.
    QStyleOptionComboBox opt;
    initStyleOption(&opt);

        // if no display text been set , use "..." as default
        if(m_DisplayText.isNull())
                opt.currentText = "...";
        else
                opt.currentText = m_DisplayText;
    painter.drawComplexControl(QStyle::CC_ComboBox, opt);

    // draw the icon and text
    painter.drawControl(QStyle::CE_ComboBoxLabel, opt);
}


void CheckBoxList::SetDisplayText(QString text)
{
        m_DisplayText = text;
}

QString CheckBoxList::GetDisplayText() const
{
        return m_DisplayText;
}
