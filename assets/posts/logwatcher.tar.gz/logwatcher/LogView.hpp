//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef LOGVIEW_HPP
#define LOGVIEW_HPP

#include <QTableView>
#include <QHeaderView>
#include <QStandardItemModel>

#include "Tools.hpp"
#include "ComboLogLevel.hpp"

/*!
  \class LogView
  \brief La vue du fichier de log
*/

class LogView : public QTableView {

Q_OBJECT

public:
    LogView();

    /*!
      \brief Redimmensionnement du tableau e en fontion de la largeur du parent.
      L'espace restant sur la droite sert pour l'affichage de la barre de défilement.
      \param parentWidth La largeur de référence, celle qui va nous permettre de nous redimmenssioner
    */
    void resize(int parentWidth); 

    /*!
      \brief Définie la ComboLogLevel depuis laquelle on va savoir si il faut afficher ou non les logs selon leur niveau d'importance.
    */
    void setCombo(ComboLogLevel *combo);

public slots :

    /*!
      \brief Une ligne a été ajoutée. Il faut la traiter pour savoir s'il faut l'afficher ou non
    */
    void lineAdded();

    /*!
     \brief Défini s'il faut afficher ou cacher les informations d'un niveau de log
     \param l Niveau de log concerné
     \param hide Faut-il cacher ce niveau ?
    */
    void hideLogLevel(LogLevel l, bool hide);


protected slots :
    /*!
      \brief Se déclenche quand le ComboLogLevel a été mis à jour. Raffraichis la vue en masquant les infos superflues.
    */
    void logsLevelUpdated();


protected :
    ComboLogLevel *m_combo;  //!< La combo depuis laquelle on va savoir si il faut afficher ou non les logs selon leur niveau d'importance.

};

#endif // LOGVIEW_HPP
