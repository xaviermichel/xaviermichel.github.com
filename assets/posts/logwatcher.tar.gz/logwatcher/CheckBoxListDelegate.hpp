//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#ifndef CHECKBOXLISTDELEGATE_HPP
#define CHECKBOXLISTDELEGATE_HPP

#include <QItemDelegate>
#include <QPainter>
#include <QModelIndex>
#include <QApplication>
#include <QCheckBox>

#include "Tools.hpp"

/*!
  \class CheckBoxListDelegate
  \see http://da-crystal.net/2008/06/checkbox-in-qcombobox/
  \brief J'ai juste ajouter une coloration dans la méthode paint et le signal updated;
*/

class CheckBoxListDelegate : public QItemDelegate {

Q_OBJECT

public:
    CheckBoxListDelegate(QObject *parent);

    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

    QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem & option, const QModelIndex & index ) const;

    void setEditorData(QWidget *editor, const QModelIndex &index) const;

    void setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const;

    void updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &index ) const;

signals :
    /*!
        \brief Ce signal est émit lorsque l'édition est terminée
    */
    void updated();


protected slots :
    /*!
        \brief Envoie le signal updated
    */
    void update();

};
#endif // CHECKBOXLISTDELEGATE_HPP
