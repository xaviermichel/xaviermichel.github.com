#ifndef LOGMODEL_HPP
#define LOGMODEL_HPP

#include <QString>
#include <QTimer>
#include <QFile>
//
// Copyright (C) 2011 Xavier MICHEL (xavier.michel.mx440@gmail.com)
//
// This software is provided as-is, without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it freely,
// subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented;
//    you must not claim that you wrote the original software.
//    If you use this software in a product, an acknowledgment
//    in the product documentation would be appreciated but is not required.
//
// 2. Altered source versions must be plainly marked as such,
//    and must not be misrepresented as being the original software.
//
// 3. This notice may not be removed or altered from any source distribution.
//

#include <QTextStream>
#include <QMap>
#include <QColor>
#include <QStandardItemModel>
#include <QMessageBox>
#include <QDebug>


#include "Tools.hpp"

/*!
  \class LogModel
  \brief Le modèle de Log. Va lire les lignes dans le fichier de log toutes les 500ms et met à jour le modèle.
*/


class LogModel : public QStandardItemModel {

Q_OBJECT


public:
    LogModel();


signals :
    /*!
      \brief Ce signal est émit quand une nouvelle ligne a été ajoutée au modèle
    */
    void lineAdded();


public slots :
    /*!
      \brief Indique qu'il faut prendre un autre fichier de log en entrée.
      \warning Cela videra le modèle actuel
      \param path Chemin vers le nouveau fichier de log
    */
    void setLogFile(const QString &path);

    /*!
      \brief Vide le modèle
    */
    void clear();


protected slots :

    /*!
      \brief Cette méthode est appelée régulièrement pour lire les mises à jour dans le fichier de logs
    */
    void readNewLogs();


private :
    QTimer *m_timer;            //!< Le timer qui appelle régulièrement readNewLogs pour mettre à jour le modèle

    qint64 m_fileSize;          //!< Dernière taille du fichier connu

    bool m_fileDefined;         //!< As-t-on défini un fichier à lire ?

    QString m_filePath;         //!< Le chemin du fichier à lire

    bool m_errorShowed;         //!< Le message d'erreur a déjà été affiché

    qint64 m_lastReadedLine;    //!< Le numéro de la dernière ligne lu
};

#endif // LOGMODEL_HPP
